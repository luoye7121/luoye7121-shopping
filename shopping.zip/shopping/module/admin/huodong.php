<?php
/**
 * @copyright   2008-2014 简好网络 <http://www.phpshe.com>
 * @creatdate   2012-1116 koyshe <koyshe@gmail.com>
 */
$menumark = 'huodong';
$seo = pe_seo($menutitle='促销活动', '', '', 'admin');
include(pe_tpl('free.html'));
?>