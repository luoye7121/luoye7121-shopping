<?php
/**
 * @copyright   2008-2015 简好网络 <http://www.phpshe.com>
 * @creatdate   2012-0501 koyshe <koyshe@gmail.com>
 */
$menumark = 'rule';
$seo = pe_seo($menutitle='商品规格', '', '', 'admin');
include(pe_tpl('free.html'));
?>