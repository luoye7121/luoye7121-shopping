<?php
$menumark = 'brand';
$seo = pe_seo($menutitle='品牌管理', '', '', 'admin');
include(pe_tpl('free.html'));
?>