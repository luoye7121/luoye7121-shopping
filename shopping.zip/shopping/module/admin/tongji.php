<?php
/**
 * @copyright   2008-2014 简好网络 <http://www.phpshe.com>
 * @creatdate   2012-0501 koyshe <koyshe@gmail.com>
 */
$menumark = 'tongji';
$seo = pe_seo($menutitle='数据统计', '', '', 'admin');
include(pe_tpl('free.html'));
?>