<?php
/**
 * @copyright   2008-2014 简好网络 <http://www.phpshe.com>
 * @creatdate   2012-1116 koyshe <koyshe@gmail.com>
 */
$menumark = 'quan';
$seo = pe_seo($menutitle='优惠券列表', '', '', 'admin');
include(pe_tpl('free.html'));
?>