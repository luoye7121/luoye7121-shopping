-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 年 02 月 19 日 06:00
-- 服务器版本: 5.5.20
-- PHP 版本: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `shopes`
--

-- --------------------------------------------------------

--
-- 表的结构 `shop_ad`
--

CREATE TABLE IF NOT EXISTS `shop_ad` (
  `ad_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_logo` varchar(100) NOT NULL,
  `ad_url` varchar(100) NOT NULL,
  `ad_position` varchar(15) NOT NULL,
  `ad_state` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '广告显示状态',
  `ad_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ad_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `shop_ad`
--

INSERT INTO `shop_ad` (`ad_id`, `ad_logo`, `ad_url`, `ad_position`, `ad_state`, `ad_order`) VALUES
(1, 'data/attachment/2015-03/20150317174225c.jpg', 'http://www.phpshe.com', 'index_jdt', 1, 1),
(2, 'data/attachment/2015-03/20150317174252u.jpg', 'http://www.phpshe.com', 'index_jdt', 1, 3),
(3, 'data/attachment/2015-03/20150317174237d.jpg', 'http://www.phpshe.com', 'index_jdt', 1, 2),
(4, 'data/attachment/2015-04/20150413161316r.gif', 'http://www.phpshe.com', 'footer', 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `shop_admin`
--

CREATE TABLE IF NOT EXISTS `shop_admin` (
  `admin_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理id',
  `admin_name` varchar(20) NOT NULL COMMENT '管理名',
  `admin_pw` varchar(32) NOT NULL COMMENT '管理密码',
  `admin_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理注册时间',
  `admin_ltime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理上次登录时间',
  `adminlevel_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `shop_admin`
--

INSERT INTO `shop_admin` (`admin_id`, `admin_name`, `admin_pw`, `admin_atime`, `admin_ltime`, `adminlevel_id`) VALUES
(1, 'admin', '93bb6e13ce60419e14beecf978654f6e', 1269059337, 1455853352, 1);

-- --------------------------------------------------------

--
-- 表的结构 `shop_adminlevel`
--

CREATE TABLE IF NOT EXISTS `shop_adminlevel` (
  `adminlevel_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理等级id',
  `adminlevel_name` varchar(20) NOT NULL COMMENT '管理等级名称',
  `adminlevel_modact` text NOT NULL COMMENT '管理等级权限',
  PRIMARY KEY (`adminlevel_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `shop_adminlevel`
--

INSERT INTO `shop_adminlevel` (`adminlevel_id`, `adminlevel_name`, `adminlevel_modact`) VALUES
(1, '总管理员', '');

-- --------------------------------------------------------

--
-- 表的结构 `shop_article`
--

CREATE TABLE IF NOT EXISTS `shop_article` (
  `article_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_name` varchar(100) NOT NULL,
  `article_text` text NOT NULL,
  `article_atime` int(10) unsigned NOT NULL DEFAULT '0',
  `article_clicknum` int(10) unsigned NOT NULL DEFAULT '0',
  `class_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_id`),
  KEY `class_id` (`class_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- 转存表中的数据 `shop_article`
--

INSERT INTO `shop_article` (`article_id`, `article_name`, `article_text`, `article_atime`, `article_clicknum`, `class_id`) VALUES
(5, '用户注册', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406563800, 55, 4),
(6, '购物流程', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564160, 38, 4),
(7, '常见问题', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564160, 28, 4),
(8, '配送时间及运费', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564220, 184, 5),
(9, '验货与签收', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564220, 175, 5),
(10, '订单查询', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564280, 19, 5),
(11, '售后政策', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564280, 49, 6),
(12, '退货说明', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564400, 4, 6),
(13, '取消订单', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564460, 11, 6),
(14, '公司简介', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564520, 59, 7),
(15, '联系我们', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564520, 8, 7),
(16, '诚聘英才', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1406564580, 41, 7),
(17, '在线支付', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1431398100, 2, 8),
(18, '货到付款', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1431398160, 0, 8),
(19, '转账汇款', '<a target="_blank" href="http://www.phpshe.com">请在此填写相关内容</a>', 1431398160, 0, 8);

-- --------------------------------------------------------

--
-- 表的结构 `shop_ask`
--

CREATE TABLE IF NOT EXISTS `shop_ask` (
  `ask_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ask_text` text NOT NULL,
  `ask_atime` int(10) unsigned NOT NULL DEFAULT '0',
  `ask_replytext` text NOT NULL,
  `ask_replytime` int(10) unsigned NOT NULL DEFAULT '0',
  `ask_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `product_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(20) NOT NULL,
  `user_ip` char(15) NOT NULL DEFAULT '0.0.0.0',
  PRIMARY KEY (`ask_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_brand`
--

CREATE TABLE IF NOT EXISTS `shop_brand` (
  `brand_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(30) NOT NULL,
  `brand_logo` varchar(255) NOT NULL COMMENT '品牌图片',
  `brand_text` varchar(255) NOT NULL COMMENT '品牌介绍',
  `brand_word` char(1) NOT NULL COMMENT '品牌首字母',
  `brand_order` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`brand_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_cart`
--

CREATE TABLE IF NOT EXISTS `shop_cart` (
  `cart_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cart_atime` int(10) unsigned NOT NULL DEFAULT '0',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0',
  `product_num` smallint(5) unsigned NOT NULL DEFAULT '1',
  `prorule_key` varchar(30) NOT NULL COMMENT '规格id组合',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cart_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_category`
--

CREATE TABLE IF NOT EXISTS `shop_category` (
  `category_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `category_pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `category_name` varchar(30) NOT NULL,
  `category_title` varchar(100) NOT NULL,
  `category_keys` varchar(255) NOT NULL,
  `category_desc` varchar(255) NOT NULL,
  `category_order` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `shop_category`
--

INSERT INTO `shop_category` (`category_id`, `category_pid`, `category_name`, `category_title`, `category_keys`, `category_desc`, `category_order`) VALUES
(1, 0, '服装', '', '', '', 0),
(2, 1, '女装', '', '', '', 1),
(3, 1, '男装', '', '', '', 1);

-- --------------------------------------------------------

--
-- 表的结构 `shop_class`
--

CREATE TABLE IF NOT EXISTS `shop_class` (
  `class_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `class_name` varchar(30) NOT NULL,
  `class_type` varchar(10) NOT NULL DEFAULT 'news' COMMENT '分类类型',
  `class_order` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`class_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `shop_class`
--

INSERT INTO `shop_class` (`class_id`, `class_name`, `class_type`, `class_order`) VALUES
(1, '网站公告', 'news', 1),
(2, '公司动态', 'news', 2);

-- --------------------------------------------------------

--
-- 表的结构 `shop_collect`
--

CREATE TABLE IF NOT EXISTS `shop_collect` (
  `collect_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `collect_atime` int(10) unsigned NOT NULL DEFAULT '0',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`collect_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `shop_collect`
--

INSERT INTO `shop_collect` (`collect_id`, `collect_atime`, `product_id`, `user_id`) VALUES
(1, 1455859849, 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `shop_comment`
--

CREATE TABLE IF NOT EXISTS `shop_comment` (
  `comment_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '留言id',
  `comment_star` tinyint(1) unsigned NOT NULL DEFAULT '5' COMMENT '评价星级',
  `comment_text` text NOT NULL COMMENT '留言内容',
  `comment_atime` int(10) NOT NULL DEFAULT '0' COMMENT '留言时间',
  `product_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL COMMENT '接受方用户id',
  `user_name` varchar(20) NOT NULL,
  `user_ip` char(15) NOT NULL DEFAULT '0.0.0.0',
  PRIMARY KEY (`comment_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_huodong`
--

CREATE TABLE IF NOT EXISTS `shop_huodong` (
  `huodong_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '活动自增id',
  `huodong_name` varchar(30) NOT NULL COMMENT '活动名称',
  `huodong_tag` varchar(10) NOT NULL COMMENT '活动价格标签',
  `huodong_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '活动开始日期',
  `huodong_stime` int(10) unsigned NOT NULL DEFAULT '0',
  `huodong_etime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '活动结束日期',
  PRIMARY KEY (`huodong_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_huodongdata`
--

CREATE TABLE IF NOT EXISTS `shop_huodongdata` (
  `huodongdata_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `huodong_id` int(10) unsigned NOT NULL DEFAULT '0',
  `huodong_tag` varchar(10) NOT NULL,
  `huodong_stime` int(10) unsigned NOT NULL DEFAULT '0',
  `huodong_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `huodong_money` decimal(10,1) unsigned NOT NULL DEFAULT '0.0',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`huodongdata_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_iplog`
--

CREATE TABLE IF NOT EXISTS `shop_iplog` (
  `iplog_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ip记录id',
  `iplog_ip` char(15) NOT NULL COMMENT 'ip记录ip',
  `iplog_ipname` varchar(20) NOT NULL COMMENT '验证码上传省份',
  `iplog_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'ip记录时间',
  `iplog_adate` date NOT NULL COMMENT 'ip记录日期',
  PRIMARY KEY (`iplog_id`),
  KEY `iplog_ip` (`iplog_ip`),
  KEY `iplog_adate` (`iplog_adate`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `shop_iplog`
--

INSERT INTO `shop_iplog` (`iplog_id`, `iplog_ip`, `iplog_ipname`, `iplog_atime`, `iplog_adate`) VALUES
(1, '127.0.0.1', '', 1431532115, '2015-05-13'),
(2, '127.0.0.1', '', 1431532868, '2015-05-14'),
(3, '127.0.0.1', '', 1455852844, '2016-02-19');

-- --------------------------------------------------------

--
-- 表的结构 `shop_link`
--

CREATE TABLE IF NOT EXISTS `shop_link` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '友情链接id',
  `link_name` varchar(50) NOT NULL COMMENT '友情链接名称',
  `link_url` varchar(100) NOT NULL COMMENT '友情链接url',
  `link_order` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '友情链接排序',
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `shop_link`
--

INSERT INTO `shop_link` (`link_id`, `link_name`, `link_url`, `link_order`) VALUES
(1, '百度', 'http://www.baidu.com', 1),
(2, '支付宝', 'http://www.alipay.com/', 2);

-- --------------------------------------------------------

--
-- 表的结构 `shop_menu`
--

CREATE TABLE IF NOT EXISTS `shop_menu` (
  `menu_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '导航id',
  `menu_name` varchar(20) NOT NULL COMMENT '导航名称',
  `menu_type` char(3) NOT NULL DEFAULT 'sys' COMMENT '导航类型',
  `menu_url` varchar(50) NOT NULL COMMENT '导航链接',
  `menu_order` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `shop_menu`
--

INSERT INTO `shop_menu` (`menu_id`, `menu_name`, `menu_type`, `menu_url`, `menu_order`) VALUES
(1, '天猫', 'diy', 'https://www.tmall.com/?spm=a21bo.7724922.8455.1.KK', 0);

-- --------------------------------------------------------

--
-- 表的结构 `shop_notice`
--

CREATE TABLE IF NOT EXISTS `shop_notice` (
  `notice_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notice_name` varchar(20) NOT NULL COMMENT '通知名称',
  `notice_mark` varchar(20) NOT NULL COMMENT '通知标识',
  `notice_obj` varchar(5) NOT NULL COMMENT '通知对象',
  `notice_emailname` varchar(100) NOT NULL COMMENT '邮件标题',
  `notice_emailtext` text NOT NULL COMMENT '邮件内容',
  `notice_state` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '通知状态',
  PRIMARY KEY (`notice_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `shop_notice`
--

INSERT INTO `shop_notice` (`notice_id`, `notice_name`, `notice_mark`, `notice_obj`, `notice_emailname`, `notice_emailtext`, `notice_state`) VALUES
(1, '用户注册', 'reg', 'user', '【注册通知】恭喜您成功注册PHPSHE商城', '<p>\r\n	尊敬的用户：\r\n</p>\r\n<p>\r\n	您好！欢迎您使用PHPSHE商城系统，您的用户名是：{user_name}。\r\n</p>', 1),
(2, '用户下单', 'order_add', 'user', '【下单通知】您的订单：{order_id}提交成功，请及时付款！', '订单金额：{order_money}\r\n<p>\r\n	收货姓名：{user_tname}\r\n</p>\r\n<p>\r\n	联系电话：{user_phone}\r\n</p>\r\n<p>\r\n	收货地址：{user_address}\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', 1),
(3, '订单付款', 'order_pay', 'user', '【付款通知】您的订单：{order_id}已付款，感谢您的购买！', '<p>\r\n	付款金额：{order_money}\r\n</p>\r\n<p>\r\n	收货姓名：{user_tname}\r\n</p>\r\n<p>\r\n	联系电话：{user_phone}\r\n</p>\r\n<p>\r\n	收货地址：{user_address}\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', 1),
(4, '订单发货', 'order_send', 'user', '【发货通知】您的订单：{order_id}已发货', '您的订单：{order_id}已发货，快递公司：{order_wl_name}，运单编号：{order_wl_id}<span class="tag_gray fl mar5 mab5" style="line-height:20px;"></span>，如有问题请及时联系！', 1),
(5, '订单关闭', 'order_close', 'user', '【订单关闭】您的订单：{order_id}已关闭', '订单金额：{order_money}\r\n<p>\r\n	收货姓名：{user_tname}\r\n</p>\r\n<p>\r\n	联系电话：{user_phone}\r\n</p>\r\n<p>\r\n	收货地址：{user_address}\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', 1),
(6, '用户下单', 'order_add', 'admin', '【下单通知】网店有新订单：{order_id}', '订单金额：{order_money}\r\n<p>\r\n	收货姓名：{user_tname}\r\n</p>\r\n<p>\r\n	联系电话：{user_phone}\r\n</p>\r\n<p>\r\n	收货地址：{user_address}\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', 1),
(7, '订单付款', 'order_pay', 'admin', '【付款通知】网店订单：{order_id}已付款', '<p>\r\n	付款金额：{order_money}\r\n</p>\r\n<p>\r\n	收货姓名：{user_tname}\r\n</p>\r\n<p>\r\n	联系电话：{user_phone}\r\n</p>\r\n<p>\r\n	收货地址：{user_address}\r\n</p>\r\n<p>\r\n	请及时安排发货！\r\n</p>', 1),
(8, '订单关闭', 'order_close', 'admin', '【订单关闭】网店订单：{order_id}已关闭', '订单金额：{order_money}\r\n<p>\r\n	收货姓名：{user_tname}\r\n</p>\r\n<p>\r\n	联系电话：{user_phone}\r\n</p>\r\n<p>\r\n	收货地址：{user_address}\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', 1);

-- --------------------------------------------------------

--
-- 表的结构 `shop_noticelog`
--

CREATE TABLE IF NOT EXISTS `shop_noticelog` (
  `noticelog_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '通知记录id',
  `noticelog_user` varchar(30) NOT NULL COMMENT '通知对象',
  `noticelog_name` varchar(100) NOT NULL COMMENT '通知名称',
  `noticelog_text` text NOT NULL COMMENT '通知内容',
  `noticelog_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '加入时间',
  `noticelog_stime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '通知时间',
  `noticelog_state` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '通知状态',
  PRIMARY KEY (`noticelog_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `shop_noticelog`
--

INSERT INTO `shop_noticelog` (`noticelog_id`, `noticelog_user`, `noticelog_name`, `noticelog_text`, `noticelog_atime`, `noticelog_stime`, `noticelog_state`) VALUES
(1, '970068343@qq.com', '【注册通知】恭喜您成功注册PHPSHE商城', '<p>\r\n	尊敬的用户：\r\n</p>\r\n<p>\r\n	您好！欢迎您使用PHPSHE商城系统，您的用户名是：hlili。\r\n</p>', 1455857604, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `shop_order`
--

CREATE TABLE IF NOT EXISTS `shop_order` (
  `order_id` bigint(15) unsigned NOT NULL COMMENT '订单id',
  `order_outid` bigint(15) unsigned NOT NULL DEFAULT '0',
  `order_money` decimal(10,1) unsigned NOT NULL DEFAULT '0.0' COMMENT '订单金额',
  `order_product_money` decimal(10,1) unsigned NOT NULL DEFAULT '0.0',
  `order_quan_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order_quan_name` varchar(30) NOT NULL,
  `order_quan_money` int(10) unsigned NOT NULL DEFAULT '0',
  `order_point_get` smallint(5) unsigned NOT NULL DEFAULT '0',
  `order_point_use` smallint(5) unsigned NOT NULL DEFAULT '0',
  `order_point_money` decimal(10,1) unsigned NOT NULL DEFAULT '0.0',
  `order_wl_id` varchar(20) NOT NULL,
  `order_wl_name` varchar(20) NOT NULL,
  `order_wl_money` decimal(5,1) unsigned NOT NULL DEFAULT '0.0',
  `order_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下单时间',
  `order_ptime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '付款时间',
  `order_stime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发货时间',
  `order_ftime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '完成时间',
  `order_payway` varchar(10) NOT NULL DEFAULT 'alipay_js',
  `order_comment` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `order_state` varchar(10) NOT NULL DEFAULT 'notpay',
  `order_text` varchar(255) NOT NULL COMMENT '订单留言',
  `order_closetext` varchar(255) NOT NULL COMMENT '订单关闭原因',
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_tname` varchar(10) NOT NULL,
  `user_phone` char(11) NOT NULL COMMENT '用户手机',
  `user_tel` varchar(20) NOT NULL,
  `user_address` varchar(255) NOT NULL COMMENT '用户地址',
  KEY `order_id` (`order_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `shop_orderdata`
--

CREATE TABLE IF NOT EXISTS `shop_orderdata` (
  `orderdata_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '订单数据id',
  `order_id` bigint(15) unsigned NOT NULL DEFAULT '0' COMMENT '订单id',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  `product_name` varchar(50) NOT NULL COMMENT '订单名称',
  `product_logo` varchar(200) NOT NULL COMMENT '商品logo',
  `product_money` decimal(10,1) NOT NULL DEFAULT '0.0',
  `product_money_yh` decimal(10,1) NOT NULL DEFAULT '0.0',
  `product_num` smallint(5) unsigned NOT NULL,
  `prorule_key` varchar(30) NOT NULL COMMENT '规格id组合',
  `prorule_name` varchar(255) NOT NULL COMMENT '规格名称组合',
  PRIMARY KEY (`orderdata_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_payway`
--

CREATE TABLE IF NOT EXISTS `shop_payway` (
  `payway_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `payway_name` varchar(10) NOT NULL,
  `payway_mark` varchar(15) NOT NULL,
  `payway_logo` varchar(100) NOT NULL,
  `payway_model` text NOT NULL,
  `payway_config` text NOT NULL,
  `payway_text` varchar(255) NOT NULL,
  `payway_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `payway_state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`payway_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `shop_payway`
--

INSERT INTO `shop_payway` (`payway_id`, `payway_name`, `payway_mark`, `payway_logo`, `payway_model`, `payway_config`, `payway_text`, `payway_order`, `payway_state`) VALUES
(1, '支付宝', 'alipay', 'include/plugin/payway/alipay/logo.gif', 'a:4:{s:12:"alipay_class";a:3:{s:4:"name";s:15:"支付宝接口";s:9:"form_type";s:6:"select";s:10:"form_value";a:3:{s:9:"alipay_js";s:18:"即时到账收款";s:9:"alipay_db";s:18:"担保交易收款";s:10:"alipay_sgn";s:15:"双功能收款";}}s:11:"alipay_name";a:2:{s:4:"name";s:15:"支付宝账户";s:9:"form_type";s:4:"text";}s:10:"alipay_pid";a:2:{s:4:"name";s:18:"合作者身份Pid";s:9:"form_type";s:4:"text";}s:10:"alipay_key";a:2:{s:4:"name";s:18:"安全校验码Key";s:9:"form_type";s:4:"text";}}', 'a:4:{s:12:"alipay_class";s:9:"alipay_js";s:11:"alipay_name";s:0:"";s:10:"alipay_pid";s:0:"";s:10:"alipay_key";s:0:"";}', '国内领先的第三方支付平台，为电子商务提供“简单、安全、快速”的在线支付解决方案。', 0, 1),
(2, '线下转账/汇款', 'bank', 'include/plugin/payway/bank/logo.gif', 'a:1:{s:9:"bank_text";a:2:{s:4:"name";s:12:"收款信息";s:9:"form_type";s:8:"textarea";}}', 'a:1:{s:9:"bank_text";s:177:"请将款项汇款至以下账户：\r\n建设银行 621700254000005xxxx 简好网络\r\n工商银行 621700254000005xxxx 简好网络\r\n农业银行 621700254000005xxxx 简好网络";}', '通过线下汇款方式支付，汇款帐号：建设银行 621700254000005xxxx 简好网络', 0, 1),
(3, '货到付款', 'cod', 'include/plugin/payway/cod/logo.gif', '', '', '送货上门后再收款，支持现金、POS机刷卡、支票支付', 0, 1),
(4, '网银在线', 'ebank', '', 'a:2:{s:8:"ebank_id";a:2:{s:4:"name";s:9:"商户号";s:9:"form_type";s:4:"text";}s:9:"ebank_md5";a:2:{s:4:"name";s:9:"MD5私钥";s:9:"form_type";s:4:"text";}}', 'a:2:{s:8:"ebank_id";s:0:"";s:9:"ebank_md5";s:0:"";}', '网银在线（www.chinabank.com.cn）全面支持全国19家银行的信用卡及借记卡实现网上支付。', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `shop_pointlog`
--

CREATE TABLE IF NOT EXISTS `shop_pointlog` (
  `pointlog_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pointlog_type` varchar(10) NOT NULL COMMENT '积分类型',
  `pointlog_in` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '积分收入',
  `pointlog_out` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '积分支出',
  `pointlog_now` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '当前结余',
  `pointlog_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '时间',
  `pointlog_text` varchar(255) NOT NULL COMMENT '备注',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `user_name` varchar(20) NOT NULL COMMENT '用户名',
  PRIMARY KEY (`pointlog_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `shop_pointlog`
--

INSERT INTO `shop_pointlog` (`pointlog_id`, `pointlog_type`, `pointlog_in`, `pointlog_out`, `pointlog_now`, `pointlog_atime`, `pointlog_text`, `user_id`, `user_name`) VALUES
(1, 'reg', 10, 0, 10, 1455857604, '注册帐号', 1, 'hlili');

-- --------------------------------------------------------

--
-- 表的结构 `shop_product`
--

CREATE TABLE IF NOT EXISTS `shop_product` (
  `product_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `product_name` varchar(50) NOT NULL COMMENT '商品名称',
  `product_text` text NOT NULL COMMENT '商品描述',
  `product_keys` varchar(50) NOT NULL COMMENT '页面关键词',
  `product_desc` varchar(255) NOT NULL COMMENT '页面描述',
  `product_logo` varchar(100) NOT NULL COMMENT '商品logo',
  `product_money` decimal(10,1) unsigned NOT NULL DEFAULT '0.0' COMMENT '商品商城价（有活动即活动价）',
  `product_smoney` decimal(10,1) unsigned NOT NULL DEFAULT '0.0' COMMENT '商品商城价',
  `product_mmoney` decimal(10,1) unsigned NOT NULL DEFAULT '0.0' COMMENT '商品市场价',
  `product_wlmoney` decimal(5,1) unsigned NOT NULL DEFAULT '0.0' COMMENT '商品物流价',
  `product_point` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '赠送积分',
  `product_mark` varchar(20) NOT NULL COMMENT '商品货号',
  `product_weight` decimal(7,2) NOT NULL COMMENT '商品尺寸',
  `product_state` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '商品状态',
  `product_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品发布时间',
  `product_num` smallint(5) unsigned NOT NULL COMMENT '商品库存数',
  `product_sellnum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品销售数',
  `product_clicknum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品点击数',
  `product_collectnum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品收藏数',
  `product_asknum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品咨询数',
  `product_commentnum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品评价数',
  `product_commentrate` varchar(10) NOT NULL COMMENT '商品评价比例',
  `product_commentstar` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品评价星级',
  `product_hd_tag` varchar(10) NOT NULL COMMENT '活动标签',
  `product_hd_stime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '活动开始时间',
  `product_hd_etime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '活动结束时间',
  `product_istuijian` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `category_id` smallint(5) unsigned NOT NULL COMMENT '商品分类id',
  `brand_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '品牌id',
  `rule_id` varchar(30) NOT NULL COMMENT '商品规格id',
  PRIMARY KEY (`product_id`),
  KEY `category_id` (`category_id`),
  KEY `brand_id` (`brand_id`),
  KEY `product_hd_etime` (`product_hd_etime`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `shop_product`
--

INSERT INTO `shop_product` (`product_id`, `product_name`, `product_text`, `product_keys`, `product_desc`, `product_logo`, `product_money`, `product_smoney`, `product_mmoney`, `product_wlmoney`, `product_point`, `product_mark`, `product_weight`, `product_state`, `product_atime`, `product_num`, `product_sellnum`, `product_clicknum`, `product_collectnum`, `product_asknum`, `product_commentnum`, `product_commentrate`, `product_commentstar`, `product_hd_tag`, `product_hd_stime`, `product_hd_etime`, `product_istuijian`, `category_id`, `brand_id`, `rule_id`) VALUES
(1, '李宁衬衣', '测试', '', '', 'data/attachment/2016-02/20160219125013k.jpg', '15.0', '15.0', '20.0', '0.0', 0, '123456', '0.00', 1, 1455857391, 100, 0, 15, 1, 0, 0, '', 0, '', 0, 0, 0, 3, 0, '');

-- --------------------------------------------------------

--
-- 表的结构 `shop_prorule`
--

CREATE TABLE IF NOT EXISTS `shop_prorule` (
  `prorule_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品规格id',
  `prorule_key` varchar(30) NOT NULL COMMENT '规格id组合',
  `product_money` decimal(10,1) unsigned NOT NULL DEFAULT '0.0' COMMENT '规格商城价',
  `product_mmoney` decimal(10,1) unsigned NOT NULL DEFAULT '0.0' COMMENT '规格市场价',
  `product_num` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '规格数量',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  PRIMARY KEY (`prorule_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_quan`
--

CREATE TABLE IF NOT EXISTS `shop_quan` (
  `quan_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '优惠券自增id',
  `quan_key` char(10) NOT NULL,
  `quan_name` varchar(30) NOT NULL COMMENT '优惠券名称',
  `quan_money` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '优惠券面值',
  `quan_limit` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '优惠券限制条件',
  `quan_num` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '优惠券发行量',
  `quan_num_get` int(10) unsigned NOT NULL DEFAULT '0',
  `quan_num_use` int(10) unsigned NOT NULL DEFAULT '0',
  `quan_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '优惠券增加日期',
  `quan_sdate` date NOT NULL COMMENT '优惠券开始日期',
  `quan_edate` date NOT NULL COMMENT '优惠券结束日期',
  `product_id` text NOT NULL COMMENT '商品id',
  PRIMARY KEY (`quan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_quanlog`
--

CREATE TABLE IF NOT EXISTS `shop_quanlog` (
  `quanlog_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '优惠券自增id',
  `quanlog_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '领取时间',
  `quanlog_utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '使用时间',
  `quanlog_state` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0未使用,1已使用,2过期',
  `quan_id` int(10) unsigned NOT NULL DEFAULT '0',
  `quan_key` char(10) NOT NULL,
  `quan_name` varchar(30) NOT NULL COMMENT '优惠券名称',
  `quan_money` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '优惠券面值',
  `quan_limit` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '优惠券限制条件',
  `quan_sdate` date NOT NULL COMMENT '优惠券开始日期',
  `quan_edate` date NOT NULL COMMENT '优惠券结束日期',
  `product_id` text NOT NULL COMMENT '商品id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(20) NOT NULL,
  PRIMARY KEY (`quanlog_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_rule`
--

CREATE TABLE IF NOT EXISTS `shop_rule` (
  `rule_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '规格id',
  `rule_name` varchar(20) NOT NULL COMMENT '规格名称',
  `rule_memo` varchar(20) NOT NULL COMMENT '规格备注',
  PRIMARY KEY (`rule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_ruledata`
--

CREATE TABLE IF NOT EXISTS `shop_ruledata` (
  `ruledata_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '规格值id',
  `ruledata_name` varchar(20) NOT NULL COMMENT '规格值名',
  `ruledata_logo` varchar(100) NOT NULL COMMENT '规格值图',
  `ruledata_order` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '规格值排序',
  `rule_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '规格id',
  PRIMARY KEY (`ruledata_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shop_setting`
--

CREATE TABLE IF NOT EXISTS `shop_setting` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text NOT NULL,
  KEY `setting_key` (`setting_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `shop_setting`
--

INSERT INTO `shop_setting` (`setting_key`, `setting_value`) VALUES
('web_title', '丽丽商城'),
('web_keywords', ''),
('web_description', ''),
('web_copyright', '丽丽网络'),
('web_tpl', 'default'),
('web_logo', 'data/attachment/2016-02/20160219122836h.png'),
('web_phone', ''),
('web_qq', ''),
('web_icp', '豫ICP备 13014394号-2'),
('web_guestbuy', '1'),
('web_hotword', ''),
('web_tongji', ''),
('web_wlname', 'a:15:{i:0;s:12:"顺丰快递";i:1;s:12:"申通快递";i:2;s:12:"圆通快递";i:3;s:12:"韵达快递";i:4;s:12:"中通快递";i:5;s:12:"天天快递";i:6;s:9:"宅急送";i:7;s:9:"EMS快递";i:8;s:12:"百事汇通";i:9;s:12:"全峰快递";i:10;s:12:"德邦物流";i:11;s:0:"";i:12;s:0:"";i:13;s:0:"";i:14;s:0:"";}'),
('email_smtp', ''),
('email_port', ''),
('email_name', ''),
('email_pw', ''),
('email_nname', ''),
('email_admin', ''),
('point_state', '0'),
('point_reg', '10'),
('point_comment', '50'),
('point_login', '2'),
('point_money', '100');

-- --------------------------------------------------------

--
-- 表的结构 `shop_user`
--

CREATE TABLE IF NOT EXISTS `shop_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `user_name` varchar(20) NOT NULL COMMENT '用户名',
  `user_pw` varchar(32) NOT NULL COMMENT '用户密码',
  `user_money` decimal(10,1) unsigned NOT NULL DEFAULT '0.0' COMMENT '账户余额',
  `user_point` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '账户积分余额',
  `user_point_all` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '累计获得积分',
  `user_tname` varchar(10) NOT NULL COMMENT '用户姓名',
  `user_phone` char(11) NOT NULL COMMENT '用户手机',
  `user_tel` varchar(20) NOT NULL COMMENT '固定电话',
  `user_qq` varchar(10) NOT NULL COMMENT '用户QQ',
  `user_email` varchar(30) NOT NULL COMMENT '用户email',
  `user_atime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户注册时间',
  `user_ltime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户上次登录时间',
  `user_address` varchar(255) NOT NULL COMMENT '用户地址',
  `user_ip` char(15) NOT NULL COMMENT '用户注册ip',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `shop_user`
--

INSERT INTO `shop_user` (`user_id`, `user_name`, `user_pw`, `user_money`, `user_point`, `user_point_all`, `user_tname`, `user_phone`, `user_tel`, `user_qq`, `user_email`, `user_atime`, `user_ltime`, `user_address`, `user_ip`) VALUES
(1, 'hlili', '7ba0d85bb776f5d7e39bdd085eebd8ad', '0.0', 10, 10, '', '', '', '', '970068343@qq.com', 1455857604, 1455857604, '', '127.0.0.1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
