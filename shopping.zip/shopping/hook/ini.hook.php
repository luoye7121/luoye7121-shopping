<?php
$ini['phpshe'] = array('version'=>'1.4', 'type'=>'0');
$ini['payway'] = array('alipay'=>'支付宝', 'alipay_js'=>'支付宝', 'alipay_db'=>'支付宝-担保交易', 'bank'=>'线下转账/汇款', 'cod'=>'货到付款', 'ebank'=>'网银在线');	
//$ini['moneylog_type'] = array('recharge'=>'账户充值', 'pay'=>'订单支付', 'cashout'=>'账户提现', 'add'=>'管理员充值', 'del'=>'管理员扣费');
$ini['pointlog_type'] = array('reg'=>'注册登录', 'comment'=>'评价获得', 'order_get'=>'交易获得', 'order_use'=>'交易使用', 'order_back'=>'交易退还', 'add'=>'系统加分', 'del'=>'系统扣除');
$ini['huodong_tag'] = array('团购', '特价', '店庆', '限时促销', '新品上市', '品牌特卖');
$ini['notice_reg'] = array('user_name'=>'用户名');
$ini['notice_order_add'] = array('order_id'=>'订单号', 'order_money'=>'订单金额', 'user_tname'=>'收件人', 'user_phone'=>'联系电话', 'user_address'=>'收货地址');
$ini['notice_order_pay'] = array('order_id'=>'订单号', 'order_money'=>'付款金额', 'user_tname'=>'收件人', 'user_phone'=>'联系电话', 'user_address'=>'收货地址');
$ini['notice_order_send'] = array('order_id'=>'订单号', 'order_money'=>'订单金额', 'user_tname'=>'收件人', 'user_phone'=>'联系电话', 'user_address'=>'收货地址', 'order_wl_name'=>'物流公司', 'order_wl_id'=>'物流单号');
$ini['notice_order_close'] = array('order_id'=>'订单号', 'order_money'=>'订单金额', 'user_tname'=>'收件人', 'user_phone'=>'联系电话', 'user_address'=>'收货地址');
?>