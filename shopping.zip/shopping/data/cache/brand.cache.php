<?php
$cache=unserialize('a:0:{}');
?>