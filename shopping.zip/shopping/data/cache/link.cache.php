<?php
$cache=unserialize('a:2:{i:0;a:4:{s:7:"link_id";s:1:"1";s:9:"link_name";s:6:"百度";s:8:"link_url";s:20:"http://www.baidu.com";s:10:"link_order";s:1:"1";}i:1;a:4:{s:7:"link_id";s:1:"2";s:9:"link_name";s:9:"支付宝";s:8:"link_url";s:22:"http://www.alipay.com/";s:10:"link_order";s:1:"2";}}');
?>