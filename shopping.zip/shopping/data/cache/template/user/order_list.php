<?php include(pe_tpl('header.html'));?>
<div class="huiyuan_content">
	<?php include(pe_tpl('user_menu.html'));?>
	<div class="fr huiyuan_main">
		<div class="hy_tt">
			<a href="<?php echo $pe['host_root'] ?>user.php?mod=order" <?php if(!$_g_state):?>class="sel"<?php endif;?>>所有订单<span class="c999 mal3 num">(<?php echo $tongji['all'] ?>)</span></a>
			<a href="<?php echo $pe['host_root'] ?>user.php?mod=order&state=notpay" <?php if($_g_state=='notpay'):?>class="sel"<?php endif;?>>待付款<span class="c999 mal3 num">(<?php echo $tongji['notpay'] ?>)</span></a>
			<a href="<?php echo $pe['host_root'] ?>user.php?mod=order&state=paid" <?php if($_g_state=='paid'):?>class="sel"<?php endif;?>>待发货<span class="c999 mal3 num">(<?php echo $tongji['paid'] ?>)</span></a>
			<a href="<?php echo $pe['host_root'] ?>user.php?mod=order&state=send" <?php if($_g_state=='send'):?>class="sel"<?php endif;?>>待确认<span class="c999 mal3 num">(<?php echo $tongji['send'] ?>)</span></a>
			<a href="<?php echo $pe['host_root'] ?>user.php?mod=order&state=success" <?php if($_g_state=='success'):?>class="sel"<?php endif;?>>交易成功<span class="c999 mal3 num">(<?php echo $tongji['success'] ?>)</span></a>
		</div>
		<div class="hy_tablelist">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<th>商品详情</th>
				<th width="90">实付款(元)</th>
				<th width="95" style="border-right:0;">交易操作</th>
			</tr>
			</table>
		</div>
		<?php foreach($info_list as $v):?>
		<?php $sel = in_array($v['order_state'], array('success', 'close'))?'hy_ordertw':'hy_ordertt'?>
		<?php $order_state = order_state($v)?>
		<div class="<?php echo $sel ?> c666">
			<span class="fl">订单编号：<span class="num"><?php echo $v['order_id'] ?></span></span>
			<span class="fl" style="margin-left:60px">下单时间：<span class="num5 c333"><?php echo pe_date($v['order_atime']) ?></span></span>
			<div class="clear"></div>
		</div>
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="hy_orderlist">
		<tr>
			<td style="text-align:left;">
				<?php foreach($v['product_list'] as $kk => $vv):?>
				<div class="dingdan_list" <?php if($kk==0):?>style="padding-top:0"<?php endif;?>>
					<a href="<?php echo pe_url('product-'.$vv['product_id']) ?>" class="fl mar5" target="_blank"><img src="<?php echo pe_thumb($vv['product_logo'], 40, 40) ?>" width="40" height="40"></a>
					<div class="fl">
						<a href="<?php echo pe_url('product-'.$vv['product_id']) ?>" title="<?php echo $vv['product_name'] ?>" target="_blank" class="cblue dd_name"><?php echo $vv['product_name'] ?></a>
						<?php if($vv['prorule_name']):?>
						<p class="c888 mat5"><?php foreach(unserialize($vv['prorule_name']) as $vvv):?>[<?php echo $vvv['name'] ?>：<?php echo $vvv['value'] ?>]&nbsp;&nbsp;<?php endforeach;?></p>
						<?php endif;?>
					</div>
					<span class="fr"><span class="num"><?php echo $vv['product_money'] ?></span>(×<?php echo $vv['product_num'] ?>)</span>
					<div class="clear"></div>
				</div>
				<?php endforeach;?>
			</td>
			<td width="90">
				<p class="corg num strong"><?php echo $v['order_money'] ?></p>
				<p class="c999 num">(含运费：<?php echo $v['order_wl_money'] ?>)</p>
				<p class="c888"><?php echo $ini['payway'][$v['order_payway']] ?></p>
			</td>
			<td width="100" style="padding:5px;">
				<?php if($order_state == 'notpay'):?>
				<p class="cred">等待买家付款</p>
				<p class="mat3"><a class="tag_org" href="index.php?mod=order&act=pay&id=<?php echo $v['order_id'] ?>" target="_blank">立即付款</a></p>
				<?php elseif($order_state == 'paid'):?>
				<p class="cred">等待发货</p>
				<?php elseif($order_state == 'send'):?>
				<p class="cred">卖家已发货</p>
					<?php if($v['order_payway']=='alipay_db'):?>
					<p class="mat3"><a class="tag_green" href="https://lab.alipay.com/consume/queryTradeDetail.htm?tradeNo=<?php echo $v['order_outid'] ?>" onclick="alert('支付宝担保交易，需要您登录支付宝网站确认收货')" target="_blank">确认收货</a></p>
					<?php elseif($v['order_payway']!='cod'):?>
					<p class="mat3"><a class="tag_green" href="user.php?mod=order&act=success&id=<?php echo $v['order_id'] ?>&token=<?php echo $pe_token ?>" onclick="return pe_cfone(this, '要确认收货')">确认收货</a></p>
					<?php endif;?>
				<?php elseif($order_state == 'success'):?>
				<p class="cgreen">交易成功</p>
					<?php if(!$v['order_comment']):?><a href="user.php?mod=order&act=comment&id=<?php echo $v['order_id'] ?>" target="_blank" class="hy_btn">评价</a><?php endif;?>
				<?php elseif($order_state == 'close'):?>
				<strike class="c999">交易关闭</strike>
				<?php endif;?>
				<p class="mat3">
					<a href="user.php?mod=order&act=view&id=<?php echo $v['order_id'] ?>" target="_blank" class="cblue">详情</a>
					<?php if($v['order_state'] == 'notpay'):?>
					| <a href="user.php?mod=order&act=close&id=<?php echo $v['order_id'] ?>" onclick="return pe_dialog(this, '取消订单', 550, 290)" class="c999">取消</a>	
					<?php endif;?>
				</p>
			</td>
		</tr>
		</table>
		<?php endforeach;?>
		<div class="fenye mat10"><?php echo $db->page->html ?></div>
	</div>
	<div class="clear"></div>
</div>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/jquery.artDialog.js?skin=chrome"></script>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/plugins/iframeTools.js"></script>
<?php include(pe_tpl('footer.html'));?>