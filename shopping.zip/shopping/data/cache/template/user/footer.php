<div class="clear"></div>
<div class="foot">
	<?php if($mod!='do'):?>
	<div class="bottom_link mat20">
		
	</div>
	<div class="bottom_img"><img src="<?php echo $pe['host_tpl'] ?>images/bottom_img.jpg"></div>
	<?php endif;?>

</div>
<link type="text/css" rel="stylesheet" href="<?php echo $pe['host_tpl'] ?>/kefu/css/style.css">
<div class="newkefu">
	<div class="newkefu_bar"></div>
	<div class="newkefu_header"></div>
	<div class="newkefu_shouqian">
        <ul>
		<?php foreach($web_qq as $v):?>
		<li><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $v ?>&site=qq&menu=yes"><img border="0" src="<?php echo $pe['host_tpl'] ?>images/qq.png" alt="在线客服" title="在线客服"></a></li>
		<?php endforeach;?>
        </ul>
	</div>
	<div class="newkefu_middle"></div>
	
    <div class="newkefu_footer"></div>
</div>
<script type="text/javascript" src="<?php echo $pe['host_root'] ?>include/js/jquery.lazyload.min.js"></script>
<script type=text/javascript>
$(function(){
	$("img.js_imgload").lazyload({
		effect:"fadeIn",
		skip_invisible : false,
		container:$("body")
	});
	$(".newkefu_bar").toggle(
		function(){
			$(".newkefu").animate({right:0});
			$(".newkefu_bar").addClass("newkefu_bar_sel");
		},
		function(){
			$(".newkefu").animate({right:"-140px"});
			$(".newkefu_bar").removeClass("newkefu_bar_sel");
		}
	);
	$(".fenlei_li").hover(
		function(){	
			$(".fenlei_li").find(".fenlei_h3 a").removeClass("sel");	
			$(this).find(".fenlei_h3 a").addClass("sel");
			$(".fenlei_li").find(".js_right").hide();	
			$(this).find(".js_right").show();
		},
		function(){
			$(".fenlei_li").find(".fenlei_h3 a").removeClass("sel");
			$(".fenlei_li").find(".js_right").hide();	
		}
	)
	<?php if($mod=='index'):?>
		$("#menu_html").show();
	<?php else:?>
		$("#menu_nav").hover(function(){
			$("#menu_html").show();
		}, function(){
			$("#menu_html").hide();	
		})
	<?php endif;?>
});
pe_loadscript("<?php echo $pe['host_root'] ?>index.php?mod=notice");
</script>
</body>
</html>