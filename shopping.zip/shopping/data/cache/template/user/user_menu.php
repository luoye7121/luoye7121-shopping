<div class="huiyuan_left">
	<h3 class="hy_tb2"><s></s>交易管理</h3>
	<ul>
		<li><a href="user.php?mod=order" <?php if($menumark=='order'):?>class="sel"<?php endif;?>>我的订单</a></li>
	</ul>
	<div class="xuxian"></div>
	<h3 class="hy_tb1"><s></s>信息管理</h3>
	<ul>
		<li><a href="user.php?mod=comment" <?php if($menumark=='comment'):?>class="sel"<?php endif;?>>我的评价</a></li>
		<li><a href="user.php?mod=collect" <?php if($menumark=='collect'):?>class="sel"<?php endif;?>>我的收藏</a></li>
	</ul>
	<div class="xuxian"></div>
	<h3 class="hy_tb3"><s></s>用户设置</h3>
	<ul>
		<li><a href="user.php?mod=setting&act=base" <?php if($menumark=='setting_base'):?>class="sel"<?php endif;?>>基本资料</a></li>
		<li style="padding-bottom:50px"><a href="user.php?mod=setting&act=pw" <?php if($menumark=='setting_pw'):?>class="sel"<?php endif;?>>修改密码</a></li>
	</ul>
</div>