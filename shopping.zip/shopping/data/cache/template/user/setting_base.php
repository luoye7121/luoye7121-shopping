<?php include(pe_tpl('header.html'));?>
<div class="huiyuan_content">
	<?php include(pe_tpl('user_menu.html'));?>
	<div class="fr huiyuan_main">
		<div class="hy_tt"><a href="javascript:;" class="sel"><?php echo $menutitle ?></a></div>
		<div class="hy_table">
		<form method="post" id="form">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td style="text-align:right;" width="150">用 户 名1：</td>
			<td><?php echo $info['user_name'] ?></td>
		</tr>
		<tr>
			<td style="text-align:right;">账户积分：</td>
			<td><span class="num"><?php echo $info['user_point'] ?></span> 积分</td>
		</tr>
		<tr>
			<td style="text-align:right;">用户姓名：</td>
			<td><input type="text" name="user_tname" value="<?php echo $info['user_tname'] ?>" class="inputall input200" /></td>
		</tr>
		<tr>
			<td style="text-align:right;">联系电话：</td>
			<td><input type="text" name="user_phone" value="<?php echo $info['user_phone'] ?>" class="inputall input200" /> <span id="user_phone_show"></span></td>
		</tr>
		<tr>
			<td style="text-align:right;">收货地址：</td>
			<td><input type="text" name="user_address" value="<?php echo $info['user_address'] ?>" class="inputall input400" /></td>
		</tr>
		<tr>
			<td style="text-align:right;">常用邮箱：</td>
			<td><input type="text" name="user_email" value="<?php echo $info['user_email'] ?>" class="inputall input200" /> <span id="user_email_show"></span></td>
		</tr>
		<tr>
			<td style="text-align:right;">注册日期：</td>
			<td><?php echo pe_date($info['user_atime']) ?></td>
		</tr>
		<tr>
			<td></td>
			<td>
				<input type="hidden" name="pe_token" value="<?php echo $pe_token ?>" />
				<input type="hidden" name="pesubmit" />	
				<input type="button" value="提交"  class="tjbtn" />
			</td>
		</tr>
		</table>
		</form>
		</div>
	</div>
	<div class="clear"></div>
</div>
<script type="text/javascript" src="<?php echo $pe['host_root'] ?>include/js/formcheck.js"></script>
<script type="text/javascript">
var form_info = [
	{"name":"user_phone", "mod":"match", "act":"blur", "arg":"phone", "show_id":"user_phone_show","show_error":"电话格式错误", "must":false},
	{"name":"user_email", "mod":"match", "act":"blur", "arg":"email", "show_id":"user_email_show","show_error":"邮箱格式错误", "must":false}
]
$(":button").pe_submit(form_info, 'form');
</script>
<?php include(pe_tpl('footer.html'));?>