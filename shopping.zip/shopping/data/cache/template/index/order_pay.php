<?php include(pe_tpl('header.html'));?>
<div class="content">
	<div class="order_cg">
		<p>
		<?php if(stripos($_SERVER['HTTP_REFERER'], 'mod=order&act=add')===false):?>
		请您及时付款，以便订单尽快处理！
		<?php elseif($order['order_payway']=='cod'):?>
		您已成功提交订单，等待管理员审核发货！
		<?php else:?>
		您已成功提交订单，请及时付款！
		<?php endif;?>
		</p>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;您的订单编号：<span class="cblue mar20"><?php echo $order['order_id'] ?></span>
		应付金额：<span class="cred font16 mar20 strong num"><?php echo $order['order_money'] ?>元</span>
		付款方式：<span class="cred font14 mar20"><?php echo $cache_payway[$order['order_payway']]['payway_name'] ?></span>
		<?php if(in_array($order['order_payway'], array('alipay', 'ebank'))):?>
		<form method="post"><input type="submit" name="pesubmit" value="去付款" class="btn_05" /></form>
		<?php elseif($order['order_payway']=='bank'):?>
		<div class="shouhuo_info"><?php echo nl2br($cache_payway[$order['order_payway']]['payway_config']['bank_text']) ?></div>
		<?php endif;?>
	</div>
<!--	<div class="liucheng" style="margin-top:15px">请选择付款方式</div>
	<div class="shouhuo_info">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="20"><input type="radio"></td>
			<td><img src="<?php echo $pe['host_tpl'] ?>images/zf_02.jpg" /></td>
		  </tr>
		</table>
		<input type="submit" value="去付款" class="btn_05" />
		<div class="hy_table">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<?php foreach($cache_payway as $k=>$v):?>
			<?php if(!$v['payway_state'])continue?>
			<tr>
				<td width="200"><label for="<?php echo $k ?>"><img src="<?php echo pe_thumb($v['payway_logo']) ?>" title="<?php echo $v['payway_name'] ?>" /></label></td>
				<td style="text-align:left"><p class="cred"><?php echo $v['payway_name'] ?>：</p><p><?php echo $v['payway_text'] ?></p></td>
				<td width="100">
				<?php if($v['payway_mark']=='bank'):?>
				<input type="button" value="支付信息" onclick='alert("订单金额：<?php echo $order['order_money'] ?>元\n\n<?php echo $cache_payway['bank']['payway_config']['bank_text'] ?>")' />
				<?php elseif($v['payway_mark']=='cod'):?>
				<form method="post">
				<input type="hidden" name="info[order_payway]" value="<?php echo $k ?>" />
				<input type="submit" name="pesubmit" value="通知发货" />
				</form>
				<?php else:?>
				<form method="post" target="_blank">
				<input type="hidden" name="info[order_payway]" value="<?php echo $k ?>" />
				<input type="submit" name="pesubmit" value="在线支付" />
				</form>
				<?php endif;?>
				</td>
			</tr>
			<?php endforeach;?>
			</table>
		</div>-->
	</div>
</div>
<script charset="utf-8" src="<?php echo $phpshe['host_root'] ?>include/plugin/artdialog/jquery.artDialog.js?skin=blue"></script>
<script charset="utf-8" src="<?php echo $phpshe['host_root'] ?>include/plugin/artdialog/plugins/iframeTools.js"></script>
<?php include(pe_tpl('footer.html'));?>