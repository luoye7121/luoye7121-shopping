<div class="remai fl">
	<div class="hot_border">
		<?php foreach((array)$cache_category_arr[$category_pid] as $k=>$v):?>
		<h3 <?php if(!is_array($cache_category_arr[$k])):?>style="border-bottom:0"<?php endif;?>><a href="<?php echo pe_url('product-list-'.$k) ?>" title="<?php echo $v['category_name'] ?>"><?php echo $v['category_name'] ?></a></h3>
		<div class="hotlist">
			<?php if(is_array($cache_category_arr[$k])):?>
			<?php foreach($cache_category_arr[$k] as $kk=>$vv):?>
			<div class="zhulei"><a href="<?php echo pe_url('product-list-'.$kk) ?>" <?php if($category_id==$kk):?>class="sel"<?php endif;?>><?php echo $vv['category_name'] ?></a></div>
			<?php endforeach;?>
			<?php endif;?>
		</div>
		<?php endforeach;?>
	</div>
	<div class="hot_border mat10">
		<h3>热销排行</h3>
		<ul class="hotlist">
			<?php foreach((array)$product_selllist as $v):?>
			<li>
				<span class="fl hotlogo"><a href="<?php echo pe_url('product-'.$v['product_id']) ?>" title="<?php echo $v['product_name'] ?>" target="_blank"><img src="<?php echo $pe['host_tpl'] ?>images/pixel.gif" data-url="<?php echo pe_thumb($v['product_logo'], 60, 60) ?>" title="<?php echo $v['product_name'] ?>" width="60" height="60" class="js_imgload" /></a></span>
				<span class="fl hotname">
					<a href="<?php echo pe_url('product-'.$v['product_id']) ?>" title="<?php echo $v['product_name'] ?>" target="_blank"><?php echo $v['product_name'] ?></a>
					<span class="cred num strong lh20">¥<?php echo $v['product_money'] ?></span>
				</span>
				<div class="clear"></div>
			</li>
			<?php endforeach;?>
		</ul>
	</div>
</div>
