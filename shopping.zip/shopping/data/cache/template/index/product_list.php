<?php include(pe_tpl('header.html'));?>
<div class="content">
	<div class="now"><?php echo $nowpath ?></div>
	<?php include(pe_tpl('product_left.html'));?>
	<div class="fr xiangqing">
		<?php if(count($cache_category_brand[$category_id])):?>
		<div class="pinpai_fl">
			<h3>品牌筛选</h3>
			<div style="padding:10px;">
			<a href="<?php echo pe_url('product-list-'.$category_id) ?>" title="全部品牌" <?php if(!$_g_brand):?>class="sel"<?php endif;?>>全部品牌</a>
			<?php foreach($cache_category_brand[$category_id] as $v):?>
			<a href="<?php echo pe_updateurl('brand', $v['brand_id']) ?>" title="<?php echo $v['brand_name'] ?>" <?php if($_g_brand==$v['brand_id']):?>class="sel"<?php endif;?>><?php echo $v['brand_name'] ?></a>
			<?php endforeach;?>
			</div>
		</div>
		<?php endif;?>
		<?php if($mod=='brand'):?>
		<div class="pp_info">
			<div class="pp_logo"><img src="<?php echo pe_thumb($info['brand_logo']) ?>" width="150" /><br /><?php echo $info['brand_name'] ?></div>
			<div class="pp_about"><span class="c333 strong">简介：</span><?php echo pe_texthtml($info['brand_text']) ?></div>
			<div class="clear"></div>
		</div>
		<?php endif;?>
		<div class="caidan">
			<ul class="fl">
				<li class="prolist_px" style="padding:0 12px;">排序：</li>
				<li class="prolist_px">
					<?php if($_g_orderby=='sellnum_asc'):?>
					<a href="<?php echo pe_updateurl('orderby', 'sellnum_desc') ?>" class="sel">销量<i class="i2"></i></a>
					<?php elseif($_g_orderby=='sellnum_desc'):?>
					<a href="<?php echo pe_updateurl('orderby', 'sellnum_asc') ?>" class="sel">销量<i class="i1"></i></a>
					<?php else:?>
					<a href="<?php echo pe_updateurl('orderby', 'sellnum_desc') ?>">销量</a>
					<?php endif;?>
				</li>
				<li class="prolist_px">
					<?php if($_g_orderby=='money_asc'):?>
					<a href="<?php echo pe_updateurl('orderby', 'money_desc') ?>" class="sel">价格<i class="i2"></i></a>
					<?php elseif($_g_orderby=='money_desc'):?>
					<a href="<?php echo pe_updateurl('orderby', 'money_asc') ?>" class="sel">价格<i class="i1"></i></a>
					<?php else:?>
					<a href="<?php echo pe_updateurl('orderby', 'money_desc') ?>">价格</a>
					<?php endif;?>
				</li>
				<li class="prolist_px">
					<?php if($_g_orderby=='clicknum_asc'):?>
					<a href="<?php echo pe_updateurl('orderby', 'clicknum_desc') ?>" class="sel">人气<i class="i2"></i></a>
					<?php elseif($_g_orderby=='clicknum_desc'):?>
					<a href="<?php echo pe_updateurl('orderby', 'clicknum_asc') ?>" class="sel">人气<i class="i1"></i></a>
					<?php else:?>
					<a href="<?php echo pe_updateurl('orderby', 'clicknum_desc') ?>">人气</a>
					<?php endif;?>
				</li>
				<li class="prolist_px"><a href="<?php echo pe_updateurl('orderby', '') ?>">默 认</a></li>
			</ul>
			<span class="fr mat8 mar10 c888">已找到 <strong><?php echo $db->page->listnums ?></strong> 个商品</span>
			<div class="clear"></div>
		</div>
		<div class="tuijian_list">
			<?php foreach($info_list as $k=>$v):?>
			<div class="prolist_1" <?php if(($k+1)%4==0):?>style="margin-right:0"<?php endif?>>
				<p class="prolist_img"><a href="<?php echo pe_url('product-'.$v['product_id']) ?>" title="<?php echo $v['product_name'] ?>" target="_blank"><img src="<?php echo $pe['host_tpl'] ?>images/pixel.gif" data-url="<?php echo pe_thumb($v['product_logo'], 220, 220) ?>" title="<?php echo $v['product_name'] ?>" width="220" height="220" class="js_imgload" /></a></p>
				<div style="padding:10px 10px 0">
					<p>
						<span class="money1 fl"><span class="num mar3">¥</span><?php echo $v['product_money'] ?></span>
						<?php if($v['product_hd_tag']):?><div class="<?php echo huodong_tag($v['product_hd_tag']) ?>"><?php echo $v['product_hd_tag'] ?></div><?php endif;?>
						<s class="num c888 fr">¥ <?php echo $v['product_mmoney'] ?></s>
					</p>
					<div class="clear"></div>
					<p class="prolist_name"><a href="<?php echo pe_url('product-'.$v['product_id']) ?>" title="<?php echo $v['product_name'] ?>" target="_blank"><?php echo $v['product_name'] ?></a></p>
				</div>
			</div>
			<?php endforeach;?>
			<div class="clear"></div>
		</div>
		<div class="clear"></div>
		<div class="fenye mat15"><?php echo $db->page->html ?></div>
	</div>
	<div class="clear"></div>
</div>
<?php include(pe_tpl('footer.html'));?>