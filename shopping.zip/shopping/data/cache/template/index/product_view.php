<?php include(pe_tpl('header.html'));?>
<div class="content">
	<div class="now"><?php echo $nowpath ?></div>
	<div class="fl proimg jqzoom">
		<img src="<?php echo $pe['host_tpl'] ?>images/pixel.gif" data-url="<?php echo pe_thumb($info['product_logo'], 400, 400) ?>" jqimg="<?php echo pe_thumb($info['product_logo']) ?>" width="400" height="400" class="js_imgload" />
		<?php if($info['product_hd_tag']):?><div class="<?php echo huodong_tag($info['product_hd_tag']) ?>"><?php echo $info['product_hd_tag'] ?></div><?php endif;?>	
	</div>
	<div class="fr proinfo">
		<h3><?php echo $info['product_name'] ?></h3>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr style="background:#d83228; background:url(<?php echo $pe['host_tpl'] ?>images/jg_bg.gif) repeat;">
			<td style="color:#fff; height:50px;" valign="top" width="60"><p class="mat5">价 格</p></td>
			<td style="color:#fff; height:50px;">
			<span class="jg_price fl">¥ <span id="product_money"><?php echo $info['product_money'] ?></span></span>
			<?php if($info['product_hd_tag']):?>
			<span class="tag_org fl mat8" style="margin-left:15px;"><?php echo $info['product_hd_tag'] ?></span>
			<span class="fl djs">剩余时间： <span id="huodong_time"></span></span>
			<?php endif;?>
			<div class="clear"></div>
			<p>
				市场价 <s class="num">¥ <span id="product_mmoney"><?php echo $info['product_mmoney'] ?></span></s>
				<span class="mal20">运费：<?php if($info['product_wlmoney'] == 0):?>卖家包邮<?php else:?><span class="num">¥ <?php echo $info['product_wlmoney'] ?></span><?php endif;?></span>
				<?php if($info['product_point']):?><span class="mal20">赠送：<span class="num mar5"><?php echo $info['product_point'] ?></span>积分</span><?php endif;?>
			</p>
			</td>
		</tr>
		<?php if(count($quan_list)):?>
		<tr style="background:#f8f8f8">
			<td>优 惠</td>
			<td>
				<?php foreach($quan_list as $v):?>
				<span class="yh_tb"><?php echo $v['quan_money'] ?>元优惠券 <a href="<?php echo pe_url('quan-'.$v['quan_key']) ?>" title="<?php echo $v['quan_name'] ?>" target="_blank" class="cblue">领取</a></span>
				<?php endforeach;?>
			</td>
		</tr>
		<?php endif;?>
		<tr>
			<td style="color:#666">销 量</td>
			<td>已售出 <span class="cred num strong"><?php echo $info['product_sellnum'] ?></span> 件 <a href="javascript:find_comment();" class="cblue font13"></a></td>
		</tr>
		<tr>
			<td style="color:#666">评 分</td>
			<td><div class="fl"><?php echo comment_star($comment_star) ?></div><a href="javascript:find_comment();" class="fl mal5 cblue font12" style="margin-top:-2px;">(已有<?php echo $info['product_commentnum'] ?>人评价)</a><div class="clear"></div></td>
		</tr>
		<?php foreach($rule_list as $k=>$v):?>
		<tr>
			<td style="color:#666"><?php echo $cache_rule[$v]['rule_name'] ?></td>
			<td>			
			<?php foreach($ruledata_list[$k] as $kk=>$vv):?>
			<?php if($cache_rule[$v]['list'][$vv]['ruledata_logo']):?>
			<span id="<?php echo $vv ?>" rule_id="<?php echo $v ?>" class="prorule_span"><img src="<?php echo pe_thumb($cache_rule[$v]['list'][$vv]['ruledata_logo']) ?>" style="width:22px;height:22px;" /></span>
			<?php else:?>
			<span id="<?php echo $vv ?>" rule_id="<?php echo $v ?>" class="prorule_span"><?php echo $cache_rule[$v]['list'][$vv]['ruledata_name'] ?></span>
			<?php endif;?>
			<?php endforeach;?>
			</td>
		</tr>
		<?php endforeach;?>
		<tr>
			<td style="color:#666">数 量</td>
			<td class="shuliang">
				<input type="hidden" name="prorule_key" />
				<span class="img1" onclick="pe_numchange('product_num', '-', 1);">-</span>
				<div class="shuliang_box"><input type="text" name="product_num" value="1" /></div>
				<span class="img2" onclick="pe_numchange('product_num', '+', <?php echo $info['product_num'] ?>);">+</span>
				<span class="fl c888 mal5 mat2">　库存<span id="product_num"><?php echo $info['product_num'] ?></span>件</span>
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><?php if($info['product_state']==2):?>
			<img src="<?php echo $pe['host_tpl'] ?>images/selldown.gif" class="fl" />
			<?php elseif($info['product_state']==1 && $info['product_num']==0):?>
			<img src="<?php echo $pe['host_tpl'] ?>images/sellout.gif" class="fl" />
			<?php else:?>
			<a href="javascript:;" onclick="return cart_add('<?php echo $info['product_id'] ?>');" class="fl"><img src="<?php echo $pe['host_tpl'] ?>images/buy.gif" /></a>
			<?php endif;?>
			<a href="javascript:collect_add('<?php echo $info['product_id'] ?>');" class="sctj fl">添加到收藏夹</a></td>
		</tr>
		</table>
		<p style="margin:10px 20px; border-top:1px #ddd dotted; padding-top:5px;">上架时间：<?php echo pe_date($info['product_atime']) ?>　　浏览次数：<?php echo $info['product_clicknum'] ?>　　收藏人数：<?php echo $info['product_collectnum'] ?></p>
		
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
	<div class="mat10"></div>
	<?php include(pe_tpl('product_left.html'));?>
	<div class="fr xiangqing">
		<div class="caidan1" id="js_menu">
			<ul class="fl">
				<li class="sel"><a href="javascript:;">商品详情</a></li>
				<li><a href="javascript:;">商品评价(<?php echo $info['product_commentnum'] ?>)</a><span id="a"></span></li>
				<li><a href="javascript:;">商品咨询(<?php echo $info['product_asknum'] ?>)</a></li>
			</ul>
			<div class="fr c666 mat10 mar10">商品货号：<?php echo $info['product_mark'] ?></div>
			<div class="clear"></div>
		</div>
		<div class="promain js_menuhtml"><?php echo $info['product_text'] ?></div>
		<!--评论 Start-->
		<div class="promain js_menuhtml" style="display:none">
			<div class="plrate">
				<div class="plrate_l fl"><strong><?php echo $comment_rate_hao ?>%</strong><p class="c888 mat3">好评度</p></div>
				<div class="plrate_m fl">
					<dl><dt>好评 <span class="c888">(<?php echo $comment_rate_hao ?>%)</span></dt><dd><div style="width:<?php echo $comment_rate_hao*2 ?>px;"></div></dd><div class="clear"></div></dl>
					<dl><dt>中评 <span class="c888">(<?php echo $comment_rate_zhong ?>%)</span></dt><dd><div style="width:<?php echo $comment_rate_zhong*2 ?>px;"></div></dd><div class="clear"></div></dl>
					<dl><dt>差评 <span class="c888">(<?php echo $comment_rate_cha ?>%)</span></dt><dd><div style="width:<?php echo $comment_rate_cha*2 ?>px;"></div></dd><div class="clear"></div></dl>
				</div>
				<div class="plrate_r">
					购买过该商品的用户可以进行评价
					<div class="mat8"><a href="<?php echo $pe['host_root'] ?>user.php?mod=order&state=success" target="_blank">发表评价<span class="font12 normal mal5"><?php echo $comment_point ?></span></a></div>
				</div>
				<div class="clear"></div>
			</div>
			<div class="plmenu" id="js_commentmenu">
				<a href="javascript:;" val="0" class="sel">全部(<?php echo $info['product_commentnum'] ?>)</a>
				<a href="javascript:;" val="hao">好评(<?php echo intval($comment_ratearr[0]) ?>)</a>
				<a href="javascript:;" val="zhong">中评(<?php echo intval($comment_ratearr[1]) ?>)</a>
				<a href="javascript:;" val="cha">差评(<?php echo intval($comment_ratearr[2]) ?>)</a>
			</div>
			<div style="border-top:1px #ddd solid;"><div id="js_commentlist"></div></div>
			<div id="js_commentpage"></div>
		</div>
		<!--评论 End-->
		<!--咨询 Start-->
		<div class="promain js_menuhtml" style="display:none">
			<div id="js_asklist"></div>
			<div id="js_askpage"></div>
			<div class="ask_form">我要提问：<input type="text" name="ask_text" class="ask_input" /><input type="button" value="提 交" class="ask_btn"></div>
		</div>
		<!--咨询 End-->
	</div>
</div>
<link type="text/css" rel="stylesheet" href="<?php echo $pe['host_root'] ?>include/plugin/jqzoom/style.css" />
<script type="text/javascript" src="<?php echo $pe['host_root'] ?>include/plugin/jqzoom/jquery.jqzoom.js"></script>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/jquery.artDialog.js?skin=simple"></script>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/plugins/iframeTools.js"></script>
<script type="text/javascript">
var menu_top = $("#js_menu").offset().top;
$(function(){
$(window).scroll(function(){
	if ( $(document).scrollTop() > menu_top) {
		$("#js_menu").addClass("js_menu");
	}
	else {
		$("#js_menu").removeClass("js_menu");	
	}
})
$(".jqzoom").jqueryzoom();
$(":input[name='product_num']").keyup(function(){
	if (!$(this).val().match(/^[1-9]+[0-9]*$/)) $(this).val(1);
})
pe_countdown("huodong_time", "<?php echo $info['product_hd_etime'] ?>");
//标签切换
$("#js_menu").find("li").click(function(){
	$("#js_menu").find("li").removeClass("sel");
	$(this).addClass("sel");
	$(".js_menuhtml").hide();
	$(".js_menuhtml").eq($("#js_menu").find("li").index($(this))).show();
	$("body,html").animate({scrollTop:menu_top},800);
	if ($(this).index() == 1) {
		comment_page(1);
	}
	else if ($(this).index() == 2) {
		ask_page(1);	
	}
})
$("#js_commentmenu").find("a").click(function(){
	$("#js_commentmenu").find("a").removeClass("sel");
	$(this).addClass("sel");
	comment_page(1);
})
//咨询发表
$(".ask_btn").click(function(){
	if (!<?php echo pe_login('user') ?>) {alert('抱歉：只有登录用户才能发表咨询！请先登录...');return;}
	var ask_text = $(":input[name='ask_text']").val();
	if (ask_text == '') {alert('咨询内容必须填写');return;}
	$.post("<?php echo $pe['host_root'] ?>index.php?mod=ask&act=add&id=<?php echo $info['product_id'] ?>", {"ask_text":ask_text, "pesubmit":true}, function(json){
		if (json.result) {
			$("#js_asklist").prepend(json.html);
			$(":input[name='ask_text']").val('');
			alert('咨询提交成功！管理员会尽快答复...');
		}
		else {
			alert('抱歉，咨询提交失败，请重新提交...')			
		}
	}, "json")
})
})
//评价跳转
function find_comment() {
	$("#js_menu").find("li").eq(1).click();
	//window.location.href = "#js_menu";
}
//评价翻页
function comment_page(page){
	$.getJSON("<?php echo $pe['host_root'] ?>index.php", {"mod":"comment","product_id":"<?php echo $info['product_id'] ?>","star":$("#js_commentmenu").find(".sel").attr("val"),"page":page,},function(json){
		$("#js_commentlist").html(json.html);
		$("#js_commentpage").html('<div class="fenye">'+json.page+'<div class="clear"></div></div>');
		$("body,html").animate({scrollTop:menu_top}, 1);	

	})
}
//咨询翻页
function ask_page(page){
	$.getJSON("<?php echo $pe['host_root'] ?>index.php", {"mod":"ask","product_id":"<?php echo $info['product_id'] ?>","page":page,},function(json){
		$("#js_asklist").html(json.html);
		$("#js_askpage").html('<div class="fenye">'+json.page+'<div class="clear"></div></div>');
		$("body,html").animate({scrollTop:menu_top}, 1);	
	})
}
//加入购物车
function cart_add(id) {
	if (<?php echo $cache_setting['web_guestbuy'] ?>==0 && !<?php echo pe_login('user') ?>) {
		window.location.href = "<?php echo $pe['host_root'] ?>user.php?mod=do&act=login";
		return false;
	}
	if ("<?php echo $info['rule_id'] ?>" != '' && $(":input[name='prorule_key']").val() == '') {
		alert('请选择商品规格');
		return false;
	}
	$.getJSON("<?php echo $pe['host_root'] ?>index.php", {"mod":"order","act":"cartadd","product_id":id,"product_num":$(":input[name='product_num']").val(),"prorule_key":$(":input[name='prorule_key']").val()},function(json){
		if (json.result == true) {
			art.dialog({
				id: 'cart_add',
				lock: true,
			    content: '<div class="gw"><p>商品已成功加入购物车！</p><a class="gw2" href="<?php echo $pe['host_root'] ?>index.php?mod=order&act=add"></a><a class="gw1" href="javascript:dialog_close();"></a></div>'
			});
		}
		else if (json.result == -1) {
			alert('商品库存不足...')
		}
		else {
			alert('抱歉，加入购物车失败，请重新加入...')
		}
		$("#cart_num").html(json.cart_num);
	})
}
function dialog_close(){
	art.dialog.list['cart_add'].close();
}
function collect_add(id) {
	if (!<?php echo pe_login('user') ?>) {alert('抱歉：只有登录用户才能收藏商品！请先登录...');return;}
	$.getJSON("<?php echo $pe['host_root'] ?>index.php", {"mod":"product","act":"collectadd","id":id},function(json){
		alert(json.show);
	})
}
$(function(){
	prorule_lock();
	$(".prorule_span").click(function(){
		if ($(this).hasClass("prorule_lock")) return;
		if ($(this).hasClass("prorule_sel")) {
			$(this).removeClass("prorule_sel");
		}
		else {
			$(this).parent().find("span").removeClass("prorule_sel");
			$(this).addClass("prorule_sel");
		}
		prorule_lock();
	})
})
function prorule_lock() {
	var prorule_list = <?php echo $prorule_json ?>;
	var prorule_sel_zuhe = new Array();
	var prorule_sel = new Array();
	var rule_sel = new Array();
	//默认规格初始化
	$(".prorule_span").removeClass("prorule_lock");
	$(".prorule_span").each(function(){
		var result = false;
		for (var i in prorule_list) {
			if (prorule_list[i]['prorule_key'].indexOf($(this).attr("id")) >= 0 && prorule_list[i]['product_num'] > 0) result = true;
			//if ($(this).hasClass("prorule_sel") && prorule_list[i]['prorule_key'].indexOf($(this).attr("id")) >= 0 && prorule_list[i]['product_num'] > 0)
		}
		if (result == false) $(this).addClass("prorule_lock");
	})
	//如果有选中项
	if ($(".prorule_sel").length > 0) {
		$(".prorule_sel").each(function(index){
			prorule_sel[index] = $(this).attr("id");
			rule_sel[index] = $(this).attr("rule_id");
		})
		//当前选中规格组合
		var prorule_key = prorule_sel.join(',');
		$(":input[name='prorule_key']").val('');
		//循环规格选中的有效列表
		for (var i in prorule_list) {
			//如果选中规格组合完成
			if (prorule_list[i]['prorule_key'] == prorule_key) {
				$(":input[name='prorule_key']").val(prorule_key);
				$("#product_money").html(prorule_list[i]['product_money']);
				$("#product_mmoney").html(prorule_list[i]['product_mmoney']);
				$("#product_num").html(prorule_list[i]['product_num']);
			}
		}
		//与选中的每个子项非同级一一匹对，找出不在有效列表里的(2014.05.14修正)
		$(".prorule_span").each(function(){
			var _span = $(this);		
			$(".prorule_sel").each(function(){
				var _sel = $(this);
				if (_span.attr("rule_id") != _sel.attr("rule_id")) {
					var result = false;
					for (var i in prorule_list) {
						if (prorule_list[i]['prorule_key'].indexOf(_sel.attr("id")) >= 0 && prorule_list[i]['prorule_key'].indexOf(_span.attr("id")) >= 0 && prorule_list[i]['product_num'] > 0) result = true;					
					}
					if (result == false) _span.addClass("prorule_lock");
				}
			})
		})
	}
}
</script>
<?php include(pe_tpl('footer.html'));?>