<div class="now">
	<a href="admin.php?mod=setting&act=base" <?php if($mod=='setting' && $act=='base'):?>class="sel"<?php endif;?>>网站设置</a>
	<!-- <a href="admin.php?mod=setting&act=point" --> <?php if($mod=='setting' && $act=='point'):?><!-- class="sel" --><?php endif;?><!-- >积分设置</a> -->
	<a href="admin.php?mod=setting&act=kuaidi" <?php if($mod=='setting' && $act=='kuaidi'):?>class="sel"<?php endif;?>>快递设置</a>
	<a href="admin.php?mod=payway" <?php if($mod=='payway'):?>class="sel"<?php endif;?>>支付设置</a>
	<div class="clear"></div>
</div>
