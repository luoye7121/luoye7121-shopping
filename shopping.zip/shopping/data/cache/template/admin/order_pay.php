<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>订单付款</title>
<link href="<?php echo $pe['host_tpl'] ?>css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo $pe['host_root'] ?>include/js/jquery.js"></script>
</head>
<body style="background:none">
<form method="post">
<table style="width:550px;margin:0;" border="0" cellspacing="0" cellpadding="0" class="wenzhang_bak">
<tr>
	<td style="border-top:0;border-left:0" class="bgtt aright c888" width="120">订单编号</td>
	<td style="border-top:0;border-right:0"><?php echo $info['order_id'] ?> </td>
</tr>
<tr>
	<td style="border-left:0" class="bgtt aright c888">收货姓名</td>
	<td style="border-right:0;"><?php echo $info['user_tname'] ?> <span class="num c888">【电话：<?php echo $info['user_phone'] ?>】</span></td>
</tr>
<tr>
	<td style="border-left:0" class="bgtt aright c888">收货地址</td>
	<td style="border-right:0;"><?php echo $info['user_address'] ?></td>
</tr>
<tr>
	<td style="border-left:0" class="bgtt aright c888">实付金额</td>
	<td style="border-right:0;"><span class="num strong corg"><?php echo $info['order_money'] ?> 元</span> <?php if($info['order_ptime']):?><span class="cgreen">[已支付]</span><?php else:?><span class="cred">[未支付]</span><?php endif?></td>
</tr>
<tr>
	<td style="border-left:0" class="bgtt aright c888">支付方式</td>
	<td style="border-right:0;"><?php echo $ini['payway'][$info['order_payway']] ?></td>
</tr>
</table>
<div class="acenter mat10">
	<input type="hidden" name="pesubmit" />
	<input type="hidden" name="pe_token" value="<?php echo $pe_token ?>" />
	<input type="submit" value="付 款" class="tjbtn" />
</div>
</form>
</body>
</html>