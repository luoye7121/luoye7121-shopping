<?php include(pe_tpl('header.html'));?>
<div class="right">
	<div class="now">
		<a href="admin.php?mod=moban" <?php if($act!='shop'):?>class="sel"<?php endif;?>>本地模板</a>
		<a href="admin.php?mod=moban&act=shop" <?php if($act=='shop'):?>class="sel"<?php endif;?>>模板商店</a>
		<div class="clear"></div>
	</div>
	<div class="tip mab5" id="jindu_load" style="display:none"><img src="<?php echo $pe['host_root'] ?>include/image/load_mini.gif" class="fl" /><span class="fl strong font16 corg mat10 mal10">模板正在安装中，请稍后...</span><div class="clear"></div></div>
	<div class="tip mab5" id="jindu_dui" style="display:none"><img src="<?php echo $pe['host_root'] ?>include/image/tip_dui.png" class="fl" /><span class="fl strong font16 cgreen mat10 mal10">恭喜，模板安装成功！</span><div class="clear"></div></div>
	<div class="tip mab5" id="jindu_cuo" style="display:none"><img src="<?php echo $pe['host_root'] ?>include/image/tip_cuo.png" class="fl" /><span class="fl strong font16 cred mat10 mal10">模板安装失败...<span id="jindu_cuo_text" class="mal5"></span></span><div class="clear"></div></div>
	<?php if($act=='shop'):?>
	<div class="admin_t_info">
		<div class="banben">
			<iframe width="100%" height="755px" frameborder="0" src="http://www.phpshe.com/shop/list"></iframe>
		</div>
	</div>
	<?php else:?>
	<div class="admin_t_info">
		<div class="banben mat10">
			<div style="margin-left:30px;">
			<?php foreach($moban_list as $k=>$v):?>
			<?php $moban_config = moban_config($v)?>
			<div class="fl mb_list">
				<img src="<?php echo pe_thumb('template/'.$v.'/index/preview.jpg') ?>" style="width:180px;height:195px" />
				<div style="background:#f3f3f3; padding:5px; text-align:left; color:#888;">
					<div class="mb_tt">名称：<?php echo $moban_config['moban_name'] ?></div>
					<div>目录：template/<?php echo $v ?></div>
				</div>
				<?php if($cache_setting['web_tpl'] == $v):?>
				<div style="position:absolute;top:1px;left:1px;"><img src="<?php echo $pe['host_tpl'] ?>images/moban_sel.png" style="border:0;" /></div>
				<?php else:?>
				<a href="admin.php?mod=moban&act=setting&tpl=<?php echo $v ?>&token=<?php echo $pe_token ?>" style="position:absolute;top:170px;left:0px;height:26px;line-height:26px;width:91px;display:none;background:#5CB85C;color:#fff" onclick="return pe_cfone(this, '使用模板')">使用模板</a>			
				<?php endif;?>
				<?php if(!in_array($v, array('default', $cache_setting['web_tpl']))):?>
				<a href="admin.php?mod=moban&act=del&tpl=<?php echo $v ?>&token=<?php echo $pe_token ?>"  style="position:absolute;top:170px;left:91px;height:26px;line-height:26px;width:91px;display:none;background:#b4b4b4;color:#fff" onclick="return pe_cfone(this, '删除模板')">删除</a>
				<?php endif;?>
			</div>
			<?php endforeach;?>
			<div class="clear"></div>
			</div>
		</div>
	</div>
	<?php endif;?>
</div>
<script type="text/javascript">
$(function(){
$(".mb_list").hover(
	function(){
		$(this).find("a").show();
	},
	function(){
		$(this).find("a").hide();					
	}
)
$.getJSON("http://www.phpshe.com/index.php?mod=api&act=moban_url&callback=?", function(json){
	alert(json.html);
})
if ("<?php echo $act ?>" == 'install') {
	$("#jindu_load").show();
	$.ajaxSettings.async = false;
	$.getJSON("<?php echo $pe['host_root'] ?>admin.php", {"mod":"moban", "act":"down", "id":"<?php echo $_g_id ?>"}, function(json){
		$("#jindu_load").hide();
		if (json.result) {
			$("#jindu_dui").show();
		}
		else {
			$("#jindu_cuo").show();
			$("#jindu_cuo_text").html(json.show);	
		}
		setTimeout(function(){
			window.location.href = "admin.php?mod=moban";
		}, 3000)
	})
}
})
</script>
<?php include(pe_tpl('footer.html'));?>