<?php include(pe_tpl('header.html'));?>
<div class="right">
	<div class="now">
		<a href="javascript:;" class="sel"><?php echo $menutitle ?></a>
		<div class="clear"></div>
	</div>
	<div class="huiyuan_main">
		<div class="ddzt" style="position:relative;">订单编号：<span class="num c888"><?php echo $info['order_id'] ?></span>， 当前订单状态：
			<?php if($order_state=='notpay'):?>
			<span class="cred mar10">等待买家付款</span>
			<a class="tag_org mar5 font12" style="padding:3px 10px" href="admin.php?mod=order&act=pay&id=<?php echo $info['order_id'] ?>" onclick="return pe_dialog(this, '订单付款', 550, 300, 'order_pay')">立即付款</a>
			<a class="hy_btn mar5" href="admin.php?mod=order&act=money&id=<?php echo $info['order_id'] ?>" onclick="return pe_dialog(this, '修改价格', 800, 400, 'order_money')">修改价格/支付方式</a>
			<a class="hy_btn mar5" href="admin.php?mod=order&act=address&id=<?php echo $info['order_id'] ?>" onclick="return pe_dialog(this, '修改收货信息', 550, 350, 'order_address')">修改收货信息</a>
			<a class="hy_btn mar5" href="admin.php?mod=order&act=close&id=<?php echo $info['order_id'] ?>" onclick="return pe_dialog(this, '关闭订单', 550, 390, 'order_close')">关闭订单</a>
			<?php elseif($order_state=='paid'):?>
			<span class="cred mar10">等待发货</span>
			<a class="tag_blue mar5 font12" style="padding:3px 10px" href="admin.php?mod=order&act=send&id=<?php echo $info['order_id'] ?>" onclick="return pe_dialog(this, '填写发货信息', 550, 390, 'order_send')">发 货</a>
			<?php if($info['order_payway']=='cod'):?>
			<a class="hy_btn mar5" href="admin.php?mod=order&act=money&id=<?php echo $info['order_id'] ?>" onclick="return pe_dialog(this, '修改价格', 800, 400, 'order_money')">修改价格/支付方式</a>
			<?php endif;?>
			<a class="hy_btn mar5" href="admin.php?mod=order&act=address&id=<?php echo $info['order_id'] ?>" onclick="return pe_dialog(this, '修改收货信息', 550, 350, 'order_address')">修改收货信息</a>
			<a class="hy_btn mar5" href="admin.php?mod=order&act=close&id=<?php echo $info['order_id'] ?>" onclick="return pe_dialog(this, '关闭订单', 550, 390, 'order_close')">关闭订单</a>
			<?php elseif($order_state=='send'):?>
			<span class="cred mar10">卖家已发货</span>
			<a class="tag_green mar5 font12" style="padding:3px 10px" href="admin.php?mod=order&act=success&id=<?php echo $info['order_id'] ?>&token=<?php echo $pe_token ?>" onclick="return pe_cfone(this, '收货')">确认收货</a>
			<a class="hy_btn mar5" href="admin.php?mod=order&act=close&id=<?php echo $info['order_id'] ?>" onclick="return pe_dialog(this, '关闭订单', 550, 390, 'order_close')">关闭订单</a>
			<?php elseif($order_state=='success'):?>
			<img src="<?php echo $pe['host_tpl'] ?>images/dui_big.png" style="position:absolute;width:35px;top:30px;" />
			<span class="cgreen" style="margin-left:45px">交易成功</span>
			<?php elseif($order_state=='close'):?>
			<span class="c999">交易关闭</span>
			<span class="cred font13">（原因：<?php echo $info['order_closetext'] ?>）</span>
			<?php endif;?>
		</div>
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="hy_tablett">
		<tr>
			<td class="bgtt" width="">商品详情</td>
			<td class="bgtt" width="80">单价(元)</td>
			<td class="bgtt" width="50">数量</td>
			<td class="bgtt" width="150">商品优惠</td>
			<td class="bgtt" width="150">实付款(元)</td>			
		</tr>
		</table>
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="list">
		<?php foreach($product_list as $k=>$v):?>
		<tr>
			<td style="text-align:left;" nosel="1">
				<div class="dingdan_list" style="padding-top:0;padding-left:15px">
					<a href="<?php echo pe_url('product-'.$v['product_id']) ?>" class="fl mar5"><img src="<?php echo pe_thumb($v['product_logo'], 40, 40) ?>" width="40" height="40" class="imgbg" /></a>
					<div class="fl font12">
						<a href="<?php echo pe_url('product-'.$v['product_id']) ?>" title="<?php echo $v['product_name'] ?>" target="_blank" class="cblue dd_name"><?php echo $v['product_name'] ?></a>
						<?php if($v['prorule_name']):?>
						<p class="c888 mat5"><?php foreach(unserialize($v['prorule_name']) as $vv):?>[<?php echo $vv['name'] ?>：<?php echo $vv['value'] ?>]&nbsp;&nbsp;<?php endforeach;?></p>
						<?php endif;?>
						</div>
					<div class="clear"></div>
				</div>
			</td>
			<td width="82" nosel="1"><span class="num"><?php echo round($v['product_money'], 1) ?></span></td>
			<td width="52" nosel="1"><span class="num"><?php echo $v['product_num'] ?></span></td>
			<td width="152" nosel="1"><?php if(order_money_yh($v['product_money_yh'])):?>卖家优惠<?php echo order_money_yh($v['product_money_yh']) ?>元<?php else:?>-<?php endif;?></td>
			<?php if($k==0):?>
			<td width="152" nosel="1" rowspan="<?php echo count($product_list) ?>" style="border-left:1px solid #eee;">
				<span class="strong num font14 corg"><?php echo round($info['order_money'], 1) ?></span>
				<p class="c888 mat2"><?php echo $ini['payway'][$info['order_payway']] ?></p>
			</td>
			<?php endif;?>
		</tr>
		<?php endforeach;?>
		</table>
		<div class="dingdan_heji">
			<span class="fl">交易获得：<span class="cgreen num"><?php echo $info['order_point_get'] ?></span> 积分</span>
			<div class="fr">
				<span class="mar20">商品总金额：<span class="cred num"><?php echo round($info['order_product_money'], 1) ?></span></span>
				<span class="mar20">运费：<span class="cred num"><?php echo round($info['order_wl_money'], 1) ?></span></span>
				<span class="mar20">使用优惠券：<a class="cred num" href="javascript:;" title="<?php echo $info['order_quan_name'] ?>">-<?php echo round($info['order_quan_money'], 1) ?></a></span>
				<span class="mar15">使用积分：<a class="cred num" href="javascript:;" title="使用<?php echo $info['order_point_use'] ?>积分">-<?php echo round($info['order_point_money'], 1) ?></a></span>
			</div>
			<div class="clear"></div>
		</div>
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="hy_tablett mat15">
		<tr>
			<td class="bgtt" width="370">订单信息</td>
			<td class="bgtt" width="400">收货信息</td>
			<td class="bgtt" colspan="2"></td>		
		</tr>
		</table>
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="wenzhang_bak">
		<tr>
			<td width="100" class="bgtt c888 aright" style="border-top:0;border-left:0;">下单时间</td>
			<td width="250" style="border-top:0;background:#fff"><?php echo pe_date($info['order_atime']) ?></td>
			<td width="100" class="bgtt c888 aright" style="border-top:0">用户帐号</td>
			<td style="border-top:0;border-right:0;background:#fff"><?php if($info['user_id']):?><span class="cblue"><?php echo $info['user_name'] ?> (ID：<?php echo $info['user_id'] ?>)</span><?php else:?><span class="c999">未登录用户<?php endif;?></td>
		</tr>
		<tr>
			<td class="bgtt c888 aright">付款时间</td>
			<td style="background:#fff"><?php if($info['order_ptime']):?><?php echo pe_date($info['order_ptime']) ?><?php else:?><span class="cred">未付款</span><?php endif;?></td>
			<td class="bgtt c888 aright">收货姓名</td>
			<td style="background:#fff;border-right:0;"><?php echo $info['user_tname'] ?></td>
		</tr>
		<tr>
			<td class="bgtt c888 aright">发货时间</td>
			<td style="background:#fff"><?php if($info['order_stime']):?><?php echo pe_date($info['order_stime']) ?><?php else:?><span class="cred">未发货</span><?php endif;?></td>	
			<td class="bgtt c888 aright">联系电话</td>
			<td style="background:#fff;border-right:0;"><?php echo $info['user_phone'] ?></td>
		</tr>
		<tr>
			<td class="bgtt c888 aright">完成时间</td>
			<td style="background:#fff"><?php if($info['order_ftime']):?><?php echo pe_date($info['order_ftime']) ?><?php else:?><span class="cred">未确认</span><?php endif;?></td>
			<td class="bgtt c888 aright">收货地址</td>
			<td style="background:#fff;border-right:0;"><?php echo $info['user_address'] ?></td>		
		</tr>
		<tr>
			<td class="bgtt c888 aright">物流信息</td>
			<td style="background:#fff"><?php if($info['order_wl_name']):?><a href="<?php echo pe_url('order-kuaidi', 'id='.$info['order_wl_id']) ?>" target="_blank" class="tag_green"><?php echo $info['order_wl_name'] ?>：<?php echo $info['order_wl_id'] ?></a><?php else:?>无<?php endif;?></td>
			<td class="bgtt c888 aright">买家留言</td>
			<td style="background:#fff;border-right:0;"><?php echo $info['order_text'] ?></td>
		</tr>		
		</table>
	</div>
</div>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/jquery.artDialog.js?skin=chrome"></script>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/plugins/iframeTools.js"></script>
<?php include(pe_tpl('footer.html'));?>