<?php include(pe_tpl('header.html'));?>
<div class="right">
	<div class="now">
		<a href="admin.php?mod=category" <?php if($act=='index'):?>class="sel"<?php endif;?>>分类列表</a>
		<a href="admin.php?mod=category&act=add" <?php if($act=='add'):?>class="sel"<?php endif;?> id="fabu">添加分类</a>
		<div class="clear"></div>
	</div>
	<form method="post" id="form">
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="list">
	<tr>
		<th class="bgtt" width="50">ID号</th>
		<th class="bgtt" width="60">排序</th>
		<th class="bgtt">分类名称</th>
		<th class="bgtt" width="165">操作</th>
	</tr>
	<?php foreach($info_list as $v):?>
	<tr>
		<td><?php echo $v['category_id'] ?></td>
		<td><input type="text" name="category_order[<?php echo $v['category_id'] ?>]" value="<?php echo $v['category_order'] ?>" class="inputtext input40" /></td>
		<td class="aleft"><a href="<?php echo pe_url('product-list-'.$v['category_id']) ?>" target="_blank"><?php echo $v['category_showname'] ?></a></td>
		<td>
			<a href="admin.php?mod=category&act=edit&id=<?php echo $v['category_id'] ?>" class="admin_edit mar5">修改</a>
			<a href="admin.php?mod=category&act=del&id=<?php echo $v['category_id'] ?>&token=<?php echo $pe_token ?>" class="admin_del" onclick="return pe_cfone(this, '删除')">删除</a>
			<a href="admin.php?mod=product&act=move&category_id=<?php echo $v['category_id'] ?>" class="hy_btn" onclick="return pe_dialog(this, '批量转移商品')">转移商品</a>
		</td>
	</tr>
	<?php endforeach;?>
	<tr>
		<td class="bgtt"></td>
		<td class="bgtt aleft" colspan="4"><button href="admin.php?mod=category&act=order&token=<?php echo $pe_token ?>" onclick="pe_doall(this,'form')">更新排序</button></td>
	</tr>
	</table>
	</form>
</div>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/jquery.artDialog.js?skin=chrome"></script>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/plugins/iframeTools.js"></script>
<?php include(pe_tpl('footer.html'));?>