<?php include(pe_tpl('header.html'));?>
<div class="right" style="background:#fff">
	<div class="now">
		<a href="admin.php?mod=order" <?php if($act=='index' && !$_g_state):?>class="sel"<?php endif;?>>全部订单（<?php echo intval($tongji['all']) ?>）</a>
		<a href="admin.php?mod=order&state=notpay" <?php if($act=='index' && $_g_state=='notpay'):?>class="sel"<?php endif;?>>等待买家付款（<?php echo intval($tongji['notpay']) ?>）</a>
		<a href="admin.php?mod=order&state=paid" <?php if($act=='index' && $_g_state=='paid'):?>class="sel"<?php endif;?>>等待发货（<?php echo intval($tongji['paid']) ?>）</a>
		<a href="admin.php?mod=order&state=send" <?php if($act=='index' && $_g_state=='send'):?>class="sel"<?php endif;?>>已发货（<?php echo intval($tongji['send']) ?>）</a>
		<a href="admin.php?mod=order&state=success" <?php if($act=='index' && $_g_state=='success'):?>class="sel"<?php endif;?>>交易成功（<?php echo intval($tongji['success']) ?>）</a>
		<a href="admin.php?mod=order&state=close" <?php if($act=='index' && $_g_state=='close'):?>class="sel"<?php endif;?>>交易关闭（<?php echo intval($tongji['close']) ?>）</a>
		<div class="clear"></div>
	</div>
	<div class="search">
		<form method="get">
			<input type="hidden" name="mod" value="<?php echo $_g_mod ?>" />
			<input type="hidden" name="state" value="<?php echo $_g_state ?>" />
			订单编号：<input type="text" name="id" value="<?php echo $_g_id ?>" class="inputtext input100 mar10" />
			姓名：<input type="text" name="user_tname" value="<?php echo $_g_user_tname ?>" class="inputtext input60 mar10" />
			电话：<input type="text" name="user_phone" value="<?php echo $_g_user_phone ?>" class="inputtext input80 mar10" />
			帐号：<input type="text" name="user_name" value="<?php echo $_g_user_name ?>" class="inputtext input80 mar10" />
			下单时间：<input type="text" name="date1" value="<?php echo $_g_date1 ?>" onfocus="WdatePicker({dateFmt:'yyyy-MM-dd'})" class="Wdate inputtext" style="width:90px;height:20px;" />	
			至 <input type="text" name="date2" value="<?php echo $_g_date2 ?>" onfocus="WdatePicker({dateFmt:'yyyy-MM-dd'})" class="Wdate inputtext" style="width:90px;height:20px;" />			
			<input type="submit" value="搜索" class="input2" />
		</form>
	</div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="list">
	<tr>
		<th class="bgtt" style="border-bottom:0;" width="">商品详情</th>
		<th class="bgtt" style="border-bottom:0;" width="95">实付款(元)</th>
		<th class="bgtt" style="border-bottom:0;" width="245">收货信息</th>
		<th class="bgtt" style="border-bottom:0;" width="50">支付状态</th>
		<th class="bgtt" style="border-bottom:0;" width="50">配送状态</th>
		<th class="bgtt" style="border-bottom:0;" width="85">交易操作</th>
	</tr>
	</table>
	<?php foreach($info_list as $k=>$v):?>
	<?php $sel = in_array($v['order_state'], array('success', 'close')) ? 'hy_ordertw' : 'hy_ordertt'?>
	<?php $order_state = order_state($v)?>
	<div class="<?php echo $sel ?> c666 <?php if($k>0):?>mat10<?php endif;?>">
		订单编号：<span class="num"><?php echo $v['order_id'] ?></span>
		<span style="margin-left:60px">下单时间：<span class="num5 c333"><?php echo pe_date($v['order_atime']) ?></span></span>
	</div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="hy_orderlist">
	<tr>
		<td class="aleft">
			<?php foreach($v['product_list'] as $kk => $vv):?>
			<div class="dingdan_list" <?php if($kk==0):?>style="padding-top:0"<?php endif;?>>
				<a href="<?php echo pe_url('product-'.$vv['product_id']) ?>" class="fl mar5" target="_blank"><img src="<?php echo pe_thumb($vv['product_logo'], 40, 40) ?>" width="40" height="40" class="imgbg" /></a>
				<div class="fl">
					<a href="<?php echo pe_url('product-'.$vv['product_id']) ?>" title="<?php echo $vv['product_name'] ?>" target="_blank" class="cblue dd_name"><?php echo $vv['product_name'] ?></a>
					<?php if($vv['prorule_name']):?>
					<p class="c888 mat5"><?php foreach(unserialize($vv['prorule_name']) as $vvv):?>[<?php echo $vvv['name'] ?>：<?php echo $vvv['value'] ?>]&nbsp;&nbsp;<?php endforeach;?></p>
					<?php endif;?>
				</div>
				<span class="fr"><span class="num"><?php echo $vv['product_money'] ?></span>(×<?php echo $vv['product_num'] ?>)</span>
				<div class="clear"></div>
			</div>
			<?php endforeach;?>
		</td>
		<td width="90">
			<p class="corg num strong"><?php echo $v['order_money'] ?></p>
			<p class="c999 num">(含运费：<?php echo $v['order_wl_money'] ?>)</p>
			<p class="c888"><?php echo $ini['payway'][$v['order_payway']] ?></p>
		</td>
		<td width="250" class="aleft" valign="top" style="padding:5px;color:#555">
			<p>【姓名】<?php echo $v['user_tname'] ?> <span class="c888">(<?php echo $v['user_phone'] ?>)</span></p>
			<p>【地址】<?php echo $v['user_address'] ?></p>
			<p>【留言】<span class="c888"><?php echo $v['order_text'] ?></span></p>
		</td>
		<td width="45"><?php if($v['order_ptime']):?>已付款<?php else:?><span class="cred">未付款</span><?php endif;?></td>
		<td width="45"><?php if($v['order_stime']):?>已发货<?php else:?><span class="cred">未发货</span><?php endif;?></td>
		<td width="90" style="padding:5px; border-right:0;">
			<?php if($order_state == 'notpay'):?>
			<p class="cred">等待买家付款</p>
			<p class="mat3"><a class="tag_org" href="admin.php?mod=order&act=pay&id=<?php echo $v['order_id'] ?>" onclick="return pe_dialog(this, '订单付款', 550, 300, 'order_pay')">立即付款</a></p>
			<?php elseif($order_state == 'paid'):?>
			<p class="cred">等待发货</p>
			<p class="mat3"><a class="tag_blue" href="admin.php?mod=order&act=send&id=<?php echo $v['order_id'] ?>" onclick="return pe_dialog(this, '填写发货信息', 550, 390, 'order_send')">发 货</a></p>
			<?php elseif($order_state == 'send'):?>
			<p class="cred">卖家已发货</p>
			<p class="mat3"><a class="tag_green" href="admin.php?mod=order&act=success&id=<?php echo $v['order_id'] ?>&token=<?php echo $pe_token ?>" onclick="return pe_cfone(this, '收货')">确认收货</a></p>
			<?php elseif($order_state == 'success'):?>
			<p class="cgreen">交易成功</p>
			<?php elseif($order_state == 'close'):?>
			<strike class="c999">交易关闭</strike>
			<?php endif;?>
			<p class="mat3">
				<a href="admin.php?mod=order&act=edit&id=<?php echo $v['order_id'] ?>" target="_blank" class="cblue">详情</a>
				<?php if($order_state == 'close'):?>
				| <a href="admin.php?mod=order&act=del&id=<?php echo $v['order_id'] ?>&token=<?php echo $pe_token ?>" onclick="return pe_cfone(this, '删除订单')" class="c999">删除</a>
				<?php elseif($order_state != 'success'):?>
				| <a href="admin.php?mod=order&act=close&id=<?php echo $v['order_id'] ?>" onclick="return pe_dialog(this, '关闭订单', 550, 390, 'order_close')" class="c999">关闭</a>
				<?php endif;?>
			</p>
		</td>
	</tr>
	</table>
	<?php endforeach;?>
	<div class="hy_pay"><div class="fenye"><?php echo $db->page->html ?></div></div>
</div>
<script type="text/javascript" src="<?php echo $pe['host_root'] ?>include/plugin/my97/WdatePicker.js"></script>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/jquery.artDialog.js?skin=chrome"></script>
<script charset="utf-8" src="<?php echo $pe['host_root'] ?>include/plugin/artdialog/plugins/iframeTools.js"></script>
<?php include(pe_tpl('footer.html'));?>