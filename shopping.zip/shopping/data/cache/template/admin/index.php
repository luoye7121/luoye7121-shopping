<?php include(pe_tpl('header.html'));?>
<div class="right">
	<!-- <div style="width:50%" class="fl">
		<div class="now">
			<a href="javascript:;" class="sel">系统信息</a>
			<div class="clear"></div>
		</div>
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="wenzhang_bak">
		<tr>
			<td class="bgtt aright" style="border-top:0;border-left:0" width="100">系统版本</td>
			<td style="border-top:0"><a href="http://www.phpshe.com" target="_blank" class="cgreen">PHPSHE<?php echo $ini['phpshe']['version'] ?>免费版</a><span class="font13 mal5 corg">(授权编号:<span id="license_num">未授权</span>)</span></td>
		</tr>
		<tr>
			<td class="bgtt aright" style="border-left:0">购买授权</td>
			<td>
				<a href="http://wpa.qq.com/msgrd?v=3&uin=76265959&site=qq&menu=yes" target="_blank"><img border="0" src="http://www.phpshe.com/template/default/index/images/qq.png" alt="咨询客服" title="咨询客服"/></a>
			</td>
		</tr>
		<tr>
			<td class="bgtt aright" style="border-left:0">官方网站</td>
			<td><a href="http://www.phpshe.com" target="_blank">http://www.phpshe.com</a></td>
		</tr>
		<tr>
			<td class="bgtt aright" style="border-left:0">模板商店</td>
			<td><a href="http://www.phpshe.com/shop/" target="_blank">http://www.phpshe.com/shop/</a></td>
		</tr>
		<tr>
			<td class="bgtt aright" style="border-left:0">服务器信息</td>
			<td><?php echo $php_os ?> <?php echo $php_apache ?> PHP/<?php echo $php_version ?> <a href="admin.php?mod=index&act=phpinfo" target="_blank" class="c888">[详情]</a></td>
		</tr>
		<tr>
			<td class="bgtt aright" style="border-left:0">数据库信息</td>
			<td><?php echo $php_mysql ?></td>
		</tr>
		</table>
	</div> -->
	<!-- <div style="width:50%" class="fl">
		<div class="now">
			<a href="javascript:;" class="sel">官方动态</a>
			<div class="clear"></div>
		</div>
		<iframe src="http://www.phpshe.com/api/shop?type=news&v=1.4" frameborder="0" width="100%" height="269px" style="border-bottom:1px solid #e8e8e8"></iframe>
	</div> -->
	<!--<div class="clear"></div>
	<div style="width:50%" class="fl">
		<div class="now">
			<a href="javascript:;" class="sel">数据统计</a>
			<div class="clear"></div>
		</div>
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="wenzhang_bak">
		<tr>
			<td class="bgtt aright" style="border-top:0;border-left:0" width="100">今日访客</td>
			<td style="border-top:0;"><span class="num"><?php echo $tongji['iplog_today'] ?></span> 人</td>
			<td class="bgtt aright" style="border-top:0;" width="100">今日订单</td>
			<td style="border-top:0;"><span class="num"><?php echo $tongji['order_today'] ?></span> 个</td>
		</tr>
		<tr>
			<td class="bgtt aright" style="border-left:0">昨日访客</td>
			<td><span class="num"><?php echo $tongji['iplog_lastday'] ?></span> 人</td>
			<td class="bgtt aright">昨日订单</td>
			<td><span class="num"><?php echo $tongji['order_lastday'] ?></span> 个</td>
		</tr>
		<tr>
			<td class="bgtt aright" style="border-left:0">累计访客</td>
			<td><span class="num"><?php echo $tongji['iplog_all'] ?></span> 人</td>
			<td class="bgtt aright">累计订单</td>
			<td><span class="num"><?php echo $tongji['order_all'] ?></span> 个</td>
		</tr>
		<tr>
			<td class="bgtt aright" style="border-left:0">今日注册</td>
			<td><span class="num"><?php echo $tongji['user_today'] ?></span> 人</td>
			<td class="bgtt aright">产品总数</td>
			<td><span class="num"><?php echo $tongji['product_num'] ?></span> 个</td>
		</tr>
		<tr>
			<td class="bgtt aright" style="border-left:0">昨日注册</td>
			<td><span class="num"><?php echo $tongji['user_lastday'] ?></span> 人</td>
			<td class="bgtt aright">咨询总数</td>
			<td><span class="num"><?php echo $tongji['ask_num'] ?></span> 条</td>
		</tr>	
		<tr>
			<td class="bgtt aright" style="border-left:0">累计注册</td>
			<td><span class="num"><?php echo $tongji['user_all'] ?></span> 人</td>
			<td class="bgtt aright">评价总数</td>
			<td><span class="num"><?php echo $tongji['comment_num'] ?></span> 条</td>
		</tr>
		</table>
	</div>
	<div style="width:50%;height:300px" class="fl">
		<div class="now">
			<a href="javascript:;" class="sel">待处理项</a>
			<div class="clear"></div>
		</div>
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="wenzhang_bak">
		<tr>
			<td style="width:25%;border-top:0;border-left:0;border-right:0;height:80px;line-height:80px;text-align:center;height:259px">
				<div class="tag_org">
					待付款订单<p class="num" style="font-size:30px;margin-top:-4px;color:#fff"><a href="admin.php?mod=order&state=notpay" target="_blank" style="color:#fff"><?php echo $tongji['order_notpay'] ?></a></p>
				</div>
			</td>
			<td style="width:25%;border-top:0;border-left:0;border-right:0;height:80px;line-height:80px;text-align:center">
				<div class="tag_blue">
					待发货订单<p class="num" style="font-size:30px;margin-top:-4px;color:#fff"><a href="admin.php?mod=order&state=paid" target="_blank" style="color:#fff"><?php echo $tongji['order_waitsend'] ?></a></p>
				</div>
			</td>
			<td style="width:25%;border-top:0;border-left:0;border-right:0;height:80px;line-height:80px;text-align:center">
				<div class="tag_green">
					待确认订单<p class="num" style="font-size:30px;margin-top:-4px;color:#fff"><a href="admin.php?mod=order&state=send" target="_blank" style="color:#fff"><?php echo $tongji['order_waitsure'] ?></a></p>
				</div>
			</td>-->
			<!-- <td style="width:25%;border-top:0;border-left:0;border-right:0;height:80px;line-height:80px;text-align:center">
				<div class="tag_gray">
					待回复咨询<p class="num" style="font-size:30px;margin-top:-4px;color:#fff"><a href="admin.php?mod=ask" target="_blank" style="color:#fff"><?php echo $tongji['ask_waitreply'] ?></a></p>
				</div>
			</td> 
		</tr>
		</table>	
	</div>
	<div class="clear"></div>-->
</div>
<script type="text/javascript">
$(function(){
	$.getJSON("http://www.phpshe.com/index.php?mod=api&act=license&callback=?", function(json){
		if (json.result) $("#license_num").html(json.license_num);
	})
})
</script>
<?php include(pe_tpl('footer.html'));?>