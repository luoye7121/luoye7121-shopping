<?php include(pe_tpl('header.html'));?>
<div class="right">
	<div class="now">
		<a href="admin.php?mod=ask" <?php if($act=='index' && !$_g_state):?>class="sel"<?php endif;?>>待回复（<?php echo $tongji[0] ?>）</a>
		<a href="admin.php?mod=ask&state=1" <?php if($act=='index' && $_g_state==='1'):?>class="sel"<?php endif;?>>已回复（<?php echo $tongji[1] ?>）</a>
		<div class="clear"></div>
	</div>
	<div class="search">
		<form method="get">
			<input type="hidden" name="mod" value="<?php echo $_g_mod ?>" />
			<input type="hidden" name="state" value="<?php echo $_g_state ?>" />
			咨询用户：<input type="text" name="user_name" value="<?php echo $_g_user_name ?>" class="inputtext input100 mar10" />
			咨询内容：<input type="text" name="text" value="<?php echo $_g_text ?>" class="inputtext input150 mar10" />
			商品名称：<input type="text" name="name" value="<?php echo $_g_name ?>" class="inputtext input150" />
			<input type="submit" value="搜索" class="input2" />
		</form>
	</div>
	<form method="post" id="form">
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="list">
	<tr>
		<th class="bgtt" width="20"><input type="checkbox" name="checkall" onclick="pe_checkall(this, 'ask_id')" /></th>
		<th class="bgtt" width="50">ID号</th>
		<th class="bgtt" width="120">咨询用户</th>
		<th class="bgtt">咨询内容</th>
		<th class="bgtt" width="250">回复内容</th>
		<th class="bgtt" colspan="2">商品信息</th>
		<th class="bgtt" width="90">操作</th>
	</tr>
	<?php foreach($info_list as $v):?>
	<tr>
		<td><input type="checkbox" name="ask_id[]" value="<?php echo $v['ask_id'] ?>" /></td>
		<td><?php echo $v['ask_id'] ?></td>
		<td><a href="http://www.ip138.com/ips.asp?ip=<?php echo $v['user_ip'] ?>" target="_blank"><?php echo $v['user_name'] ?></a></td>
		<td class="aleft" valign="top"><?php echo $v['ask_text'] ?><p class="font12 c999 num mat2">[<?php echo pe_date($v['ask_atime']) ?>]</p></td>
		<td class="aleft" valign="top"><?php if($v['ask_replytext']):?><span class="cred"><?php echo $v['ask_replytext'] ?></span><p class="font12 cred num mat2">[<?php echo pe_date($v['ask_replytime']) ?>]</p><?php endif;?></td>
		<td width="40"><a href="<?php echo pe_url('product-'.$v['product_id']) ?>" target="_blank"><img src="<?php echo pe_thumb($v['product_logo'], 40, 40) ?>" width="40" height="40" class="imgbg" /></a></td>
		<td class="aleft" width="210" style="padding-left:0"><a href="<?php echo pe_url('product-'.$v['product_id']) ?>" target="_blank" class="cblue"><?php echo $v['product_name'] ?></a></td>
		<td>
			<a href="admin.php?mod=ask&act=edit&id=<?php echo $v['ask_id'] ?>&<?php echo pe_fromto() ?>" class="admin_edit mar5">修改</a>
			<a href="admin.php?mod=ask&act=del&id=<?php echo $v['ask_id'] ?>&token=<?php echo $pe_token ?>" class="admin_del" onclick="return pe_cfone(this, '删除')">删除</a>
		</td>
	</tr>
	<?php endforeach;?>
	<tr>
		<th class="bgtt" align="center"><input type="checkbox" name="checkall" onclick="pe_checkall(this, 'ask_id')" /></td>
		<th class="bgtt" colspan="7">
			<span class="fl"><button href="admin.php?mod=ask&act=del&token=<?php echo $pe_token ?>" onclick="return pe_cfall(this, 'ask_id', 'form', '批量删除')">批量删除</button></span>
			<span class="fenye"><?php echo $db->page->html ?></span>
		</td>
	</tr>
	</table>
	</form>
</div>
<?php include(pe_tpl('footer.html'));?>