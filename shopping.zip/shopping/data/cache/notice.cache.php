<?php
$cache=unserialize('a:4:{s:9:"order_add";a:2:{s:4:"user";a:7:{s:9:"notice_id";s:1:"2";s:11:"notice_name";s:12:"用户下单";s:11:"notice_mark";s:9:"order_add";s:10:"notice_obj";s:4:"user";s:16:"notice_emailname";s:76:"【下单通知】您的订单：{order_id}提交成功，请及时付款！";s:16:"notice_emailtext";s:173:"订单金额：{order_money}
<p>
	收货姓名：{user_tname}
</p>
<p>
	联系电话：{user_phone}
</p>
<p>
	收货地址：{user_address}
</p>
<p>
	<br />
</p>";s:12:"notice_state";s:1:"1";}s:5:"admin";a:7:{s:9:"notice_id";s:1:"6";s:11:"notice_name";s:12:"用户下单";s:11:"notice_mark";s:9:"order_add";s:10:"notice_obj";s:5:"admin";s:16:"notice_emailname";s:49:"【下单通知】网店有新订单：{order_id}";s:16:"notice_emailtext";s:173:"订单金额：{order_money}
<p>
	收货姓名：{user_tname}
</p>
<p>
	联系电话：{user_phone}
</p>
<p>
	收货地址：{user_address}
</p>
<p>
	<br />
</p>";s:12:"notice_state";s:1:"1";}}s:9:"order_pay";a:2:{s:4:"user";a:7:{s:9:"notice_id";s:1:"3";s:11:"notice_name";s:12:"订单付款";s:11:"notice_mark";s:9:"order_pay";s:10:"notice_obj";s:4:"user";s:16:"notice_emailname";s:76:"【付款通知】您的订单：{order_id}已付款，感谢您的购买！";s:16:"notice_emailtext";s:185:"<p>
	付款金额：{order_money}
</p>
<p>
	收货姓名：{user_tname}
</p>
<p>
	联系电话：{user_phone}
</p>
<p>
	收货地址：{user_address}
</p>
<p>
	<br />
</p>";s:12:"notice_state";s:1:"1";}s:5:"admin";a:7:{s:9:"notice_id";s:1:"7";s:11:"notice_name";s:12:"订单付款";s:11:"notice_mark";s:9:"order_pay";s:10:"notice_obj";s:5:"admin";s:16:"notice_emailname";s:52:"【付款通知】网店订单：{order_id}已付款";s:16:"notice_emailtext";s:203:"<p>
	付款金额：{order_money}
</p>
<p>
	收货姓名：{user_tname}
</p>
<p>
	联系电话：{user_phone}
</p>
<p>
	收货地址：{user_address}
</p>
<p>
	请及时安排发货！
</p>";s:12:"notice_state";s:1:"1";}}s:10:"order_send";a:1:{s:4:"user";a:7:{s:9:"notice_id";s:1:"4";s:11:"notice_name";s:12:"订单发货";s:11:"notice_mark";s:10:"order_send";s:10:"notice_obj";s:4:"user";s:16:"notice_emailname";s:52:"【发货通知】您的订单：{order_id}已发货";s:16:"notice_emailtext";s:200:"您的订单：{order_id}已发货，快递公司：{order_wl_name}，运单编号：{order_wl_id}<span class="tag_gray fl mar5 mab5" style="line-height:20px;"></span>，如有问题请及时联系！";s:12:"notice_state";s:1:"1";}}s:11:"order_close";a:2:{s:4:"user";a:7:{s:9:"notice_id";s:1:"5";s:11:"notice_name";s:12:"订单关闭";s:11:"notice_mark";s:11:"order_close";s:10:"notice_obj";s:4:"user";s:16:"notice_emailname";s:52:"【订单关闭】您的订单：{order_id}已关闭";s:16:"notice_emailtext";s:173:"订单金额：{order_money}
<p>
	收货姓名：{user_tname}
</p>
<p>
	联系电话：{user_phone}
</p>
<p>
	收货地址：{user_address}
</p>
<p>
	<br />
</p>";s:12:"notice_state";s:1:"1";}s:5:"admin";a:7:{s:9:"notice_id";s:1:"8";s:11:"notice_name";s:12:"订单关闭";s:11:"notice_mark";s:11:"order_close";s:10:"notice_obj";s:5:"admin";s:16:"notice_emailname";s:52:"【订单关闭】网店订单：{order_id}已关闭";s:16:"notice_emailtext";s:173:"订单金额：{order_money}
<p>
	收货姓名：{user_tname}
</p>
<p>
	联系电话：{user_phone}
</p>
<p>
	收货地址：{user_address}
</p>
<p>
	<br />
</p>";s:12:"notice_state";s:1:"1";}}}');
?>